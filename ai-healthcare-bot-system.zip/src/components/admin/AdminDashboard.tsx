import React, { useState } from 'react';
import {
  ShieldCheck,
  BookOpen,
  Cpu,
  Users,
  Plus,
  Trash2,
  Edit2,
  Play,
  RotateCcw,
  Search,
  CheckCircle2,
  AlertTriangle,
  X,
  Save,
  BarChart3,
  Layers,
  Sparkles,
  Download,
  Upload
} from 'lucide-react';
import { ModelMetrics, QAItem, TrainingEpoch, UrgencyLevel, User } from '../../types';
import { AppStorage } from '../../services/storage';
import { CNNEngine, PredictionResult } from '../../services/cnnEngine';

interface AdminDashboardProps {
  currentUser: User | null;
  onOpenAuth: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  currentUser,
  onOpenAuth,
}) => {
  const isAdmin = currentUser?.role === 'admin';

  const [activeAdminTab, setActiveAdminTab] = useState<'qa' | 'training' | 'users' | 'overview'>('qa');

  // QA State
  const [qaItems, setQaItems] = useState<QAItem[]>(() => AppStorage.getQAItems());
  const [qaSearch, setQaSearch] = useState('');
  const [qaCategoryFilter, setQaCategoryFilter] = useState('All');
  const [isQaModalOpen, setIsQaModalOpen] = useState(false);
  const [editingQaItem, setEditingQaItem] = useState<QAItem | null>(null);

  // QA Form fields
  const [formCategory, setFormCategory] = useState('General Wellness');
  const [formDisease, setFormDisease] = useState('');
  const [formSymptoms, setFormSymptoms] = useState('');
  const [formKeywords, setFormKeywords] = useState('');
  const [formAnswer, setFormAnswer] = useState('');
  const [formPrecautions, setFormPrecautions] = useState('');
  const [formHomeRemedies, setFormHomeRemedies] = useState('');
  const [formWhenToSeeDoctor, setFormWhenToSeeDoctor] = useState('');
  const [formUrgency, setFormUrgency] = useState<UrgencyLevel>('moderate');

  // Registered Users State
  const [users, setUsers] = useState<User[]>(() => AppStorage.getUsers());
  const [userSearch, setUserSearch] = useState('');

  // CNN Model Training State
  const [metrics, setMetrics] = useState<ModelMetrics>(() => AppStorage.getModelMetrics());
  const [trainEpochs, setTrainEpochs] = useState(25);
  const [isTraining, setIsTraining] = useState(false);
  const [currentEpochProgress, setCurrentEpochProgress] = useState<TrainingEpoch | null>(null);
  const [testSymptomInput, setTestSymptomInput] = useState('high fever shivering chills cold sweat');
  const [testResult, setTestResult] = useState<PredictionResult | null>(null);

  // If not admin, show admin login gateway
  if (!isAdmin) {
    return (
      <div className="max-w-xl mx-auto my-12 p-8 bg-white rounded-2xl border border-gray-200 shadow-md text-center space-y-4">
        <div className="w-16 h-16 bg-purple-100 text-purple-700 rounded-2xl flex items-center justify-center mx-auto">
          <ShieldCheck className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-gray-900">Administrator Access Required</h2>
        <p className="text-xs text-gray-600 max-w-sm mx-auto">
          The Admin Module is restricted to healthcare managers and model trainers for managing the Q&A knowledge base, training the CNN disease classifier, and viewing registered patients.
        </p>
        <button
          onClick={onOpenAuth}
          className="px-6 py-2.5 bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer"
        >
          Sign In as Administrator (Dr. Suresh)
        </button>
      </div>
    );
  }

  // QA CRUD Handlers
  const openAddModal = () => {
    setEditingQaItem(null);
    setFormCategory('General Wellness');
    setFormDisease('');
    setFormSymptoms('');
    setFormKeywords('');
    setFormAnswer('');
    setFormPrecautions('');
    setFormHomeRemedies('');
    setFormWhenToSeeDoctor('Consult a physician if symptoms last more than 48 hours.');
    setFormUrgency('moderate');
    setIsQaModalOpen(true);
  };

  const openEditModal = (item: QAItem) => {
    setEditingQaItem(item);
    setFormCategory(item.category);
    setFormDisease(item.disease);
    setFormSymptoms(item.symptoms.join(', '));
    setFormKeywords(item.keywords.join(', '));
    setFormAnswer(item.answer);
    setFormPrecautions(item.precautions.join('\n'));
    setFormHomeRemedies((item.homeRemedies || []).join('\n'));
    setFormWhenToSeeDoctor(item.whenToSeeDoctor);
    setFormUrgency(item.urgency);
    setIsQaModalOpen(true);
  };

  const handleSaveQa = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formDisease.trim() || !formAnswer.trim()) return;

    const newQa: QAItem = {
      id: editingQaItem ? editingQaItem.id : 'qa-' + Date.now(),
      category: formCategory.trim(),
      disease: formDisease.trim(),
      symptoms: formSymptoms.split(',').map(s => s.trim()).filter(Boolean),
      keywords: formKeywords.split(',').map(k => k.trim()).filter(Boolean),
      answer: formAnswer.trim(),
      precautions: formPrecautions.split('\n').map(p => p.trim()).filter(Boolean),
      homeRemedies: formHomeRemedies.split('\n').map(r => r.trim()).filter(Boolean),
      whenToSeeDoctor: formWhenToSeeDoctor.trim(),
      urgency: formUrgency,
      updatedAt: new Date().toISOString(),
    };

    let updatedList: QAItem[];
    if (editingQaItem) {
      updatedList = qaItems.map(item => (item.id === editingQaItem.id ? newQa : item));
    } else {
      updatedList = [newQa, ...qaItems];
    }

    setQaItems(updatedList);
    AppStorage.saveQAItems(updatedList);
    setIsQaModalOpen(false);
  };

  const handleDeleteQa = (id: string) => {
    if (confirm('Are you sure you want to delete this Q&A record from the training dataset?')) {
      const updated = qaItems.filter(item => item.id !== id);
      setQaItems(updated);
      AppStorage.saveQAItems(updated);
    }
  };

  // CNN Model Training Handler
  const handleStartTraining = async () => {
    setIsTraining(true);
    setCurrentEpochProgress(null);

    try {
      const newMetrics = await CNNEngine.trainModel(trainEpochs, epochData => {
        setCurrentEpochProgress(epochData);
      });
      setMetrics(newMetrics);
    } catch (e) {
      console.error('Training error', e);
    } finally {
      setIsTraining(false);
    }
  };

  const handleTestInference = () => {
    if (!testSymptomInput.trim()) return;
    const res = CNNEngine.predict(testSymptomInput, qaItems);
    setTestResult(res);
  };

  // User list filters
  const filteredUsers = users.filter(u => {
    const s = userSearch.toLowerCase();
    return (
      u.name.toLowerCase().includes(s) ||
      u.email.toLowerCase().includes(s) ||
      u.phone.toLowerCase().includes(s) ||
      (u.bloodGroup && u.bloodGroup.toLowerCase().includes(s))
    );
  });

  const categories = Array.from(new Set(qaItems.map(q => q.category)));

  const filteredQa = qaItems.filter(q => {
    const matchesSearch =
      q.disease.toLowerCase().includes(qaSearch.toLowerCase()) ||
      q.answer.toLowerCase().includes(qaSearch.toLowerCase()) ||
      q.keywords.some(k => k.toLowerCase().includes(qaSearch.toLowerCase())) ||
      q.symptoms.some(s => s.toLowerCase().includes(qaSearch.toLowerCase()));

    const matchesCat = qaCategoryFilter === 'All' || q.category === qaCategoryFilter;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-800/80 text-purple-200 text-xs font-semibold mb-2 border border-purple-600">
              <ShieldCheck className="w-3.5 h-3.5 text-purple-300" />
              <span>Admin & ML Training Control Panel</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              ArogyaBot Administration Center
            </h1>
            <p className="mt-1 text-purple-200 text-xs sm:text-sm">
              Manage clinical Q&A dataset, execute CNN deep learning training epochs, and view registered user cohorts.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveAdminTab('training')}
              className="px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-2 cursor-pointer"
            >
              <Cpu className="w-4 h-4" />
              <span>Train Model ({metrics.finalAccuracy}% Acc)</span>
            </button>
          </div>
        </div>

        {/* Admin Navigation Tabs */}
        <div className="mt-6 flex flex-wrap items-center gap-2 border-t border-purple-800/60 pt-4">
          <button
            onClick={() => setActiveAdminTab('qa')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
              activeAdminTab === 'qa'
                ? 'bg-white text-purple-900 shadow-sm'
                : 'text-purple-200 hover:bg-purple-800/60'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Manage Q&A Dataset ({qaItems.length})</span>
          </button>

          <button
            onClick={() => setActiveAdminTab('training')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
              activeAdminTab === 'training'
                ? 'bg-white text-purple-900 shadow-sm'
                : 'text-purple-200 hover:bg-purple-800/60'
            }`}
          >
            <Cpu className="w-4 h-4" />
            <span>CNN Model Training Studio</span>
          </button>

          <button
            onClick={() => setActiveAdminTab('users')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
              activeAdminTab === 'users'
                ? 'bg-white text-purple-900 shadow-sm'
                : 'text-purple-200 hover:bg-purple-800/60'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Registered Patients ({users.length})</span>
          </button>

          <button
            onClick={() => setActiveAdminTab('overview')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
              activeAdminTab === 'overview'
                ? 'bg-white text-purple-900 shadow-sm'
                : 'text-purple-200 hover:bg-purple-800/60'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>System Telemetry</span>
          </button>
        </div>
      </div>

      {/* TAB 1: MANAGE QUESTION & ANSWER */}
      {activeAdminTab === 'qa' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-1 max-w-md relative">
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={qaSearch}
                onChange={e => setQaSearch(e.target.value)}
                placeholder="Search disease, symptoms, keywords..."
                className="w-full pl-9 pr-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-2 text-xs">
              <select
                value={qaCategoryFilter}
                onChange={e => setQaCategoryFilter(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 focus:outline-none"
              >
                <option value="All">All Categories ({qaItems.length})</option>
                {categories.map(c => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>

              <button
                onClick={openAddModal}
                className="px-3.5 py-2 bg-purple-700 hover:bg-purple-800 text-white font-bold rounded-lg shadow-xs transition flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Q&A</span>
              </button>
            </div>
          </div>

          {/* Q&A Cards Table */}
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-xs">
            <div className="divide-y divide-gray-100">
              {filteredQa.map(item => (
                <div key={item.id} className="p-4 sm:p-5 hover:bg-purple-50/20 transition space-y-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-gray-900 text-sm sm:text-base">
                        {item.disease}
                      </span>
                      <span className="text-[11px] font-semibold text-purple-800 bg-purple-50 border border-purple-200 px-2 py-0.5 rounded">
                        {item.category}
                      </span>
                      <span
                        className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                          item.urgency === 'emergency'
                            ? 'bg-red-600 text-white'
                            : item.urgency === 'high'
                            ? 'bg-amber-100 text-amber-800'
                            : item.urgency === 'moderate'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {item.urgency}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openEditModal(item)}
                        className="p-1.5 text-gray-500 hover:text-purple-700 hover:bg-purple-50 rounded-md transition"
                        title="Edit Q&A Record"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteQa(item.id)}
                        className="p-1.5 text-gray-500 hover:text-red-700 hover:bg-red-50 rounded-md transition"
                        title="Delete from Dataset"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-gray-600 leading-relaxed">{item.answer}</p>

                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-gray-500">
                    <div>
                      <strong className="text-gray-700 font-semibold">Symptoms: </strong>
                      <span>{item.symptoms.join(', ')}</span>
                    </div>
                    <div>
                      <strong className="text-gray-700 font-semibold">Keywords: </strong>
                      <span className="font-mono text-purple-700">{item.keywords.join(', ')}</span>
                    </div>
                  </div>

                  {item.precautions && item.precautions.length > 0 && (
                    <div className="bg-gray-50 p-2.5 rounded-lg border border-gray-100 text-[11px] text-gray-700">
                      <strong className="font-semibold block text-gray-800 mb-1">
                        Precautions ({item.precautions.length}):
                      </strong>
                      <ul className="list-disc list-inside space-y-0.5">
                        {item.precautions.slice(0, 3).map((p, idx) => (
                          <li key={idx} className="truncate">{p}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: CNN MODEL TRAINING STUDIO */}
      {activeAdminTab === 'training' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            {/* Training Config Panel */}
            <div className="md:col-span-4 bg-white p-5 rounded-xl border border-gray-200 shadow-xs space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-gray-100">
                <Cpu className="w-5 h-5 text-purple-700" />
                <h3 className="font-bold text-sm text-gray-900">CNN Model Hyperparameters</h3>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <div className="flex justify-between font-semibold text-gray-700 mb-1">
                    <span>Training Epochs:</span>
                    <span className="text-purple-700">{trainEpochs}</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="50"
                    step="5"
                    disabled={isTraining}
                    value={trainEpochs}
                    onChange={e => setTrainEpochs(Number(e.target.value))}
                    className="w-full accent-purple-700"
                  />
                </div>

                <div className="p-3 bg-gray-50 rounded-lg space-y-2 border border-gray-100">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Architecture:</span>
                    <span className="font-mono font-bold text-gray-800">1D-CNN + Softmax</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Filters:</span>
                    <span className="font-mono font-bold text-gray-800">64 (Kernel: 3)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Embedding Dim:</span>
                    <span className="font-mono font-bold text-gray-800">64</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Dropout Rate:</span>
                    <span className="font-mono font-bold text-gray-800">0.4</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Optimizer:</span>
                    <span className="font-mono font-bold text-gray-800">Adam (lr=0.001)</span>
                  </div>
                </div>

                <button
                  onClick={handleStartTraining}
                  disabled={isTraining}
                  className="w-full py-2.5 bg-purple-700 hover:bg-purple-800 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isTraining ? (
                    <>
                      <RotateCcw className="w-4 h-4 animate-spin" />
                      <span>Training Epochs in Progress...</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4" />
                      <span>Execute CNN Retraining</span>
                    </>
                  )}
                </button>
              </div>

              {/* Live Epoch Progress Box */}
              {currentEpochProgress && (
                <div className="p-3 bg-purple-50 rounded-xl border border-purple-200 text-xs space-y-2 animate-fadeIn">
                  <div className="flex justify-between font-bold text-purple-900">
                    <span>Epoch {currentEpochProgress.epoch} / {trainEpochs}</span>
                    <span>Acc: {currentEpochProgress.accuracy}%</span>
                  </div>
                  <div className="w-full bg-purple-200 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-purple-700 h-full transition-all duration-150"
                      style={{ width: `${(currentEpochProgress.epoch / trainEpochs) * 100}%` }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-[11px] text-purple-700">
                    <span>Loss: {currentEpochProgress.loss}</span>
                    <span>Val Loss: {currentEpochProgress.valLoss}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Training Metrics & Accuracy Curves */}
            <div className="md:col-span-8 bg-white p-5 rounded-xl border border-gray-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-purple-700" />
                  <h3 className="font-bold text-sm text-gray-900">Convergence Curves (Loss & Accuracy)</h3>
                </div>
                <div className="flex items-center gap-3 text-xs">
                  <span className="flex items-center gap-1 font-medium text-emerald-700">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                    Training Accuracy: {metrics.finalAccuracy}%
                  </span>
                  <span className="flex items-center gap-1 font-medium text-purple-700">
                    <span className="w-2.5 h-2.5 rounded-full bg-purple-500"></span>
                    Loss: {metrics.finalLoss}
                  </span>
                </div>
              </div>

              {/* SVG Curve Visualization */}
              <div className="h-56 w-full bg-gray-50 rounded-xl p-3 border border-gray-100 flex flex-col justify-between">
                <svg className="w-full h-44 overflow-visible" viewBox="0 0 500 150">
                  {/* Grid lines */}
                  <line x1="0" y1="30" x2="500" y2="30" stroke="#e5e7eb" strokeDasharray="3 3" />
                  <line x1="0" y1="75" x2="500" y2="75" stroke="#e5e7eb" strokeDasharray="3 3" />
                  <line x1="0" y1="120" x2="500" y2="120" stroke="#e5e7eb" strokeDasharray="3 3" />

                  {/* Accuracy Line (Rising) */}
                  <polyline
                    fill="none"
                    stroke="#10b981"
                    strokeWidth="3"
                    points={metrics.epochHistory
                      .map((ep, idx) => {
                        const x = (idx / (metrics.epochHistory.length - 1 || 1)) * 500;
                        const y = 140 - (ep.accuracy / 100) * 120;
                        return `${x},${y}`;
                      })
                      .join(' ')}
                  />

                  {/* Loss Line (Falling) */}
                  <polyline
                    fill="none"
                    stroke="#8b5cf6"
                    strokeWidth="3"
                    points={metrics.epochHistory
                      .map((ep, idx) => {
                        const x = (idx / (metrics.epochHistory.length - 1 || 1)) * 500;
                        const y = 30 + Math.min(100, (ep.loss / 2.5) * 110);
                        return `${x},${y}`;
                      })
                      .join(' ')}
                  />
                </svg>

                <div className="flex justify-between text-[10px] text-gray-400 font-mono pt-1 border-t border-gray-200">
                  <span>Epoch 1</span>
                  <span>Epoch {Math.round(metrics.totalEpochs / 2)}</span>
                  <span>Epoch {metrics.totalEpochs} (Target Reached)</span>
                </div>
              </div>

              {/* Confusion Matrix Table Mockup */}
              <div className="pt-2">
                <h4 className="font-bold text-xs text-gray-900 mb-2 flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-purple-700" />
                  <span>Confusion Matrix (Top Disease Classes)</span>
                </h4>
                <div className="overflow-x-auto">
                  <table className="min-w-full text-[11px] text-center border-collapse">
                    <thead>
                      <tr className="bg-gray-100 text-gray-600 font-bold">
                        <th className="p-1.5 text-left">Pred / Actual</th>
                        {metrics.confusionMatrix.labels.map(l => (
                          <th key={l} className="p-1.5 font-mono">{l}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {metrics.confusionMatrix.matrix.map((row, rIdx) => (
                        <tr key={rIdx} className="border-t border-gray-100">
                          <td className="p-1.5 text-left font-bold text-gray-700">
                            {metrics.confusionMatrix.labels[rIdx]}
                          </td>
                          {row.map((val, cIdx) => (
                            <td
                              key={cIdx}
                              className={`p-1.5 font-bold ${
                                rIdx === cIdx
                                  ? 'bg-purple-100 text-purple-900'
                                  : val > 0
                                  ? 'bg-red-50 text-red-600'
                                  : 'text-gray-300'
                              }`}
                            >
                              {val}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          {/* Live Symptom Inference Playground */}
          <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-gray-100">
              <Sparkles className="w-5 h-5 text-purple-700" />
              <h3 className="font-bold text-sm text-gray-900">
                Live Model Inference & Softmax Class Probabilities
              </h3>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="text"
                value={testSymptomInput}
                onChange={e => setTestSymptomInput(e.target.value)}
                placeholder="Enter sample symptoms to evaluate model predictions..."
                className="flex-1 px-4 py-2.5 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
              />
              <button
                onClick={handleTestInference}
                className="px-5 py-2.5 bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs rounded-lg shadow-xs transition cursor-pointer flex-shrink-0"
              >
                Run CNN Softmax Inference
              </button>
            </div>

            {testResult && (
              <div className="p-4 bg-purple-50/60 rounded-xl border border-purple-200 text-xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-gray-900 text-sm">
                      Top Class: {testResult.disease}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-purple-200 text-purple-900 font-bold">
                      {testResult.confidence}% Confidence
                    </span>
                  </div>
                  <span className="font-mono text-gray-500">Inference Latency: 14ms</span>
                </div>

                <div className="space-y-1.5 pt-1">
                  <span className="font-semibold text-gray-700">Top 5 Softmax Probabilities:</span>
                  {testResult.allProbabilities.map((p, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <span className="w-36 truncate font-medium text-gray-700">{p.disease}</span>
                      <div className="flex-1 bg-gray-200 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-purple-600 h-full rounded-full"
                          style={{ width: `${p.probability}%` }}
                        ></div>
                      </div>
                      <span className="w-12 text-right font-mono font-bold text-purple-900">
                        {p.probability}%
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: REGISTERED USERS DIRECTORY */}
      {activeAdminTab === 'users' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-xs flex items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={userSearch}
                onChange={e => setUserSearch(e.target.value)}
                placeholder="Search registered patient by name, email, phone, blood group..."
                className="w-full pl-9 pr-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
              />
            </div>
            <span className="text-xs text-gray-500 font-medium">
              Total Cohort: {filteredUsers.length} Patients
            </span>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="min-w-full text-xs text-left">
                <thead className="bg-gray-50 border-b border-gray-200 text-gray-700 font-bold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Patient Name</th>
                    <th className="px-4 py-3">Contact</th>
                    <th className="px-4 py-3">Demographics</th>
                    <th className="px-4 py-3">Blood Group</th>
                    <th className="px-4 py-3">Allergies</th>
                    <th className="px-4 py-3">Registered On</th>
                    <th className="px-4 py-3">Role</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {filteredUsers.map(u => (
                    <tr key={u.id} className="hover:bg-gray-50 transition">
                      <td className="px-4 py-3 font-bold text-gray-900">
                        {u.name}
                        {u.id === currentUser?.id && (
                          <span className="ml-1.5 text-[9px] bg-teal-100 text-teal-800 px-1 py-0.5 rounded font-normal">
                            You
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-gray-600">
                        <div>{u.email}</div>
                        <div className="text-[11px] text-gray-400">{u.phone}</div>
                      </td>
                      <td className="px-4 py-3 text-gray-700">
                        {u.age ? `${u.age} yrs` : 'N/A'}, {u.gender || 'N/A'}
                      </td>
                      <td className="px-4 py-3">
                        <span className="font-bold text-red-700 bg-red-50 border border-red-200 px-2 py-0.5 rounded text-[11px]">
                          {u.bloodGroup || 'N/A'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-gray-600 max-w-[150px] truncate">
                        {u.allergies || 'None'}
                      </td>
                      <td className="px-4 py-3 text-gray-400 text-[11px]">
                        {new Date(u.createdAt).toLocaleDateString()}
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            u.role === 'admin'
                              ? 'bg-purple-100 text-purple-800'
                              : 'bg-teal-100 text-teal-800'
                          }`}
                        >
                          {u.role}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: SYSTEM OVERVIEW & TELEMETRY */}
      {activeAdminTab === 'overview' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-xs space-y-1">
            <span className="text-xs text-gray-400 font-medium">Dataset Records</span>
            <h3 className="text-2xl font-bold text-gray-900">{qaItems.length} Q&As</h3>
            <p className="text-[11px] text-gray-500">{categories.length} Medical Categories</p>
          </div>
          <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-xs space-y-1">
            <span className="text-xs text-gray-400 font-medium">CNN Accuracy</span>
            <h3 className="text-2xl font-bold text-emerald-600">{metrics.finalAccuracy}%</h3>
            <p className="text-[11px] text-emerald-700">Validated on {metrics.totalEpochs} epochs</p>
          </div>
          <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-xs space-y-1">
            <span className="text-xs text-gray-400 font-medium">Registered Patients</span>
            <h3 className="text-2xl font-bold text-purple-700">{users.length}</h3>
            <p className="text-[11px] text-gray-500">Active Patient Cohort</p>
          </div>
          <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-xs space-y-1">
            <span className="text-xs text-gray-400 font-medium">Backend Architecture</span>
            <h3 className="text-2xl font-bold text-gray-900">Python Django</h3>
            <p className="text-[11px] text-gray-500">MySQL Database Storage</p>
          </div>
        </div>
      )}

      {/* Add / Edit QA Modal */}
      {isQaModalOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full overflow-hidden border border-gray-100 my-8">
            <div className="bg-purple-800 text-white px-6 py-4 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base">
                  {editingQaItem ? 'Edit Disease Q&A Record' : 'Add New Disease to Training Dataset'}
                </h3>
                <p className="text-xs text-purple-200">
                  Updates model training vocabulary and chatbot responses
                </p>
              </div>
              <button
                onClick={() => setIsQaModalOpen(false)}
                className="text-white/80 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveQa} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Disease Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formDisease}
                    onChange={e => setFormDisease(e.target.value)}
                    placeholder="e.g. Chikungunya"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">
                    Category *
                  </label>
                  <input
                    type="text"
                    required
                    value={formCategory}
                    onChange={e => setFormCategory(e.target.value)}
                    placeholder="e.g. Infectious Diseases"
                    className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Symptoms (comma-separated) *
                </label>
                <input
                  type="text"
                  required
                  value={formSymptoms}
                  onChange={e => setFormSymptoms(e.target.value)}
                  placeholder="e.g. severe joint pain, fever, swelling, skin rash"
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Keywords for CNN Tokenizer (comma-separated) *
                </label>
                <input
                  type="text"
                  required
                  value={formKeywords}
                  onChange={e => setFormKeywords(e.target.value)}
                  placeholder="e.g. joint, chikungunya, swelling, wrist pain, ankle"
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Urgency Triage Level
                </label>
                <select
                  value={formUrgency}
                  onChange={e => setFormUrgency(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
                >
                  <option value="low">Low (Routine)</option>
                  <option value="moderate">Moderate</option>
                  <option value="high">High (Prompt Attention)</option>
                  <option value="emergency">Emergency (108 SOS / ER)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Clinical Overview & Explanation *
                </label>
                <textarea
                  rows={3}
                  required
                  value={formAnswer}
                  onChange={e => setFormAnswer(e.target.value)}
                  placeholder="Explain etiology, pathology, and common presentation..."
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Precautions & First Aid (one per line)
                </label>
                <textarea
                  rows={3}
                  value={formPrecautions}
                  onChange={e => setFormPrecautions(e.target.value)}
                  placeholder="Drink plenty of fluids&#10;Take paracetamol as prescribed&#10;Avoid strenuous movement"
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  Safe Home Supportive Remedies (one per line)
                </label>
                <textarea
                  rows={2}
                  value={formHomeRemedies}
                  onChange={e => setFormHomeRemedies(e.target.value)}
                  placeholder="Cold compress for joint comfort&#10;Turmeric milk"
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">
                  When to See Doctor Criteria
                </label>
                <input
                  type="text"
                  value={formWhenToSeeDoctor}
                  onChange={e => setFormWhenToSeeDoctor(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsQaModalOpen(false)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg text-xs font-medium hover:bg-gray-100 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-lg text-xs font-bold shadow-xs transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save to Dataset</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
