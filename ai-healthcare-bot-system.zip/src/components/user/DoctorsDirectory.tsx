import React, { useState } from 'react';
import {
  Search,
  MapPin,
  Phone,
  Star,
  Clock,
  Calendar,
  Filter,
  CheckCircle,
  Stethoscope,
  X,
  Navigation,
  Compass
} from 'lucide-react';
import { Doctor } from '../../types';
import { AppStorage } from '../../services/storage';

export const DoctorsDirectory: React.FC = () => {
  const [doctors] = useState<Doctor[]>(() => AppStorage.getDoctors());
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('All');
  const [selectedCity, setSelectedCity] = useState('Delhi NCR');
  const [onlyAvailableToday, setOnlyAvailableToday] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [patientName, setPatientName] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [appointmentDate, setAppointmentDate] = useState('');
  const [appointmentSlot, setAppointmentSlot] = useState('10:00 AM - 11:00 AM');

  const specialties = [
    'All',
    'General Physician',
    'Cardiologist',
    'Pediatrician',
    'Orthopedic',
    'Gynecologist',
    'Pulmonologist',
    'Dermatologist',
  ];

  const cities = [
    'Delhi NCR',
    'Mumbai',
    'Bengaluru',
    'Chennai',
    'Kolkata',
    'Rural PHC Adarsh Gram',
  ];

  const filteredDoctors = doctors.filter(doc => {
    const matchesSearch =
      doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.clinicName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.specialty.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doc.address.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesSpecialty =
      selectedSpecialty === 'All' || doc.specialty.toLowerCase().includes(selectedSpecialty.toLowerCase());

    const matchesAvailability = !onlyAvailableToday || doc.availableToday;

    return matchesSearch && matchesSpecialty && matchesAvailability;
  });

  const handleBookSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setBookingSuccess(true);
    setTimeout(() => {
      setBookingSuccess(false);
      setSelectedDoctor(null);
    }, 2200);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header Section */}
      <div className="bg-gradient-to-r from-teal-800 to-teal-900 rounded-2xl p-6 sm:p-8 text-white shadow-sm">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-700/80 text-teal-200 text-xs font-semibold mb-3 border border-teal-600">
            <Compass className="w-3.5 h-3.5" />
            <span>Google Places & Health Directory API Integration</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Find Certified Doctors & Clinics Nearby
          </h1>
          <p className="mt-2 text-teal-100 text-sm sm:text-base leading-relaxed">
            Locate verified healthcare professionals, clinics, and specialists near your location. Connect via instant direct dial or reserve your appointment consultation.
          </p>
        </div>

        {/* Location & Search Controls */}
        <div className="mt-6 grid grid-cols-1 sm:grid-cols-12 gap-3">
          <div className="sm:col-span-4 relative">
            <MapPin className="w-4 h-4 text-teal-300 absolute left-3 top-3" />
            <select
              value={selectedCity}
              onChange={e => setSelectedCity(e.target.value)}
              className="w-full pl-9 pr-3 py-2.5 bg-teal-950/60 border border-teal-600/60 rounded-xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
            >
              {cities.map(c => (
                <option key={c} value={c} className="bg-gray-900 text-white">
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-8 relative">
            <Search className="w-4 h-4 text-teal-300 absolute left-3 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search by doctor name, clinic, or medical specialty..."
              className="w-full pl-9 pr-3 py-2.5 bg-teal-950/60 border border-teal-600/60 rounded-xl text-white placeholder-teal-300/70 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
            />
          </div>
        </div>
      </div>

      {/* Specialty Filter Pills & Toggles */}
      <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-x-auto py-1 text-xs">
          <span className="text-gray-400 font-medium flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" />
            Specialty:
          </span>
          {specialties.map(spec => (
            <button
              key={spec}
              onClick={() => setSelectedSpecialty(spec)}
              className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                selectedSpecialty === spec
                  ? 'bg-teal-700 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {spec}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-3 text-xs">
          <label className="flex items-center gap-2 text-gray-700 font-medium cursor-pointer">
            <input
              type="checkbox"
              checked={onlyAvailableToday}
              onChange={e => setOnlyAvailableToday(e.target.checked)}
              className="rounded text-teal-600 focus:ring-teal-500"
            />
            <span>Available Today Only</span>
          </label>
        </div>
      </div>

      {/* Main Content Area: Map Simulation & Doctors List */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Interactive Map Visualizer */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-gray-200 p-4 shadow-xs flex flex-col justify-between h-[520px] sticky top-20">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-gray-100 mb-3">
              <div className="flex items-center gap-2">
                <Navigation className="w-4 h-4 text-teal-700" />
                <h3 className="font-bold text-sm text-gray-900">Map View & Local Clinics</h3>
              </div>
              <span className="text-xs text-teal-700 font-medium bg-teal-50 px-2 py-0.5 rounded">
                Radius: 5 km ({selectedCity})
              </span>
            </div>

            {/* Simulated Live Google Places Map Graphic */}
            <div className="relative w-full h-80 rounded-lg overflow-hidden bg-slate-100 border border-slate-200 flex items-center justify-center p-4">
              {/* Map grid lines */}
              <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#0d9488_1px,transparent_1px)] [background-size:16px_16px]"></div>

              {/* Road vectors simulation */}
              <svg className="absolute inset-0 w-full h-full stroke-gray-300 stroke-[3]" xmlns="http://www.w3.org/2000/svg">
                <path d="M 0 60 Q 150 120 400 90" fill="none" stroke="#cbd5e1" strokeWidth="4" />
                <path d="M 80 0 L 120 320" fill="none" stroke="#cbd5e1" strokeWidth="6" />
                <path d="M 280 0 L 240 320" fill="none" stroke="#cbd5e1" strokeWidth="4" />
                <path d="M 0 220 C 180 200 240 280 400 240" fill="none" stroke="#cbd5e1" strokeWidth="5" />
              </svg>

              {/* User Center Pin */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center z-10">
                <div className="w-4 h-4 bg-teal-600 rounded-full border-2 border-white shadow-md animate-ping"></div>
                <div className="w-4 h-4 bg-teal-600 rounded-full border-2 border-white shadow-md absolute"></div>
                <span className="mt-2 text-[10px] font-bold bg-white/90 px-1.5 py-0.5 rounded shadow-xs text-gray-800">
                  Your Location
                </span>
              </div>

              {/* Doctor Pins */}
              {filteredDoctors.map((doc, idx) => {
                const offsets = [
                  { top: '25%', left: '30%' },
                  { top: '35%', left: '75%' },
                  { top: '70%', left: '25%' },
                  { top: '65%', left: '68%' },
                  { top: '15%', left: '60%' },
                  { top: '80%', left: '48%' },
                  { top: '48%', left: '18%' },
                ];
                const pos = offsets[idx % offsets.length];

                return (
                  <button
                    key={doc.id}
                    onClick={() => setSelectedDoctor(doc)}
                    style={{ top: pos.top, left: pos.left }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 group z-20 cursor-pointer"
                    title={`${doc.name} - ${doc.clinicName}`}
                  >
                    <div className="w-7 h-7 rounded-full bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center shadow-lg border-2 border-white transition transform group-hover:scale-110">
                      <Stethoscope className="w-3.5 h-3.5" />
                    </div>
                    <span className="opacity-0 group-hover:opacity-100 transition absolute -bottom-5 left-1/2 -translate-x-1/2 whitespace-nowrap bg-gray-900 text-white text-[10px] px-1.5 py-0.5 rounded pointer-events-none shadow-md">
                      {doc.name.split(',')[0]} ({doc.distanceKm} km)
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="mt-3 p-3 bg-teal-50 rounded-lg text-xs text-teal-900 border border-teal-200">
            <p className="font-semibold flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-teal-700" />
              Verified Clinic Locations
            </p>
            <p className="text-[11px] text-teal-800/80 mt-0.5">
              Click any pin on the map to preview clinic schedule and consultation booking details.
            </p>
          </div>
        </div>

        {/* Doctor Cards Listing */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between text-xs text-gray-500">
            <span>Showing {filteredDoctors.length} verified physicians & clinics</span>
            <span>Sorted by nearest distance</span>
          </div>

          {filteredDoctors.length === 0 ? (
            <div className="bg-white rounded-xl border border-gray-200 p-8 text-center">
              <Stethoscope className="w-10 h-10 text-gray-400 mx-auto mb-3" />
              <h4 className="font-bold text-gray-800 text-sm">No clinics found matching criteria</h4>
              <p className="text-xs text-gray-500 mt-1">Try switching the specialty filter or expanding your location search.</p>
            </div>
          ) : (
            filteredDoctors.map(doc => (
              <div
                key={doc.id}
                className="bg-white rounded-xl border border-gray-200 p-5 shadow-xs hover:border-teal-300 transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-gray-900 text-base">{doc.name}</h3>
                    {doc.availableToday && (
                      <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                        Available Today
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-teal-700 font-semibold">{doc.specialty}</p>

                  <p className="text-xs text-gray-500">
                    {doc.qualification} • {doc.experienceYears} Years Experience
                  </p>

                  <div className="flex flex-wrap items-center gap-y-1 gap-x-3 text-xs text-gray-600 pt-1">
                    <span className="flex items-center gap-1 font-medium text-gray-800">
                      <MapPin className="w-3.5 h-3.5 text-gray-400" />
                      {doc.clinicName}, {doc.address}
                    </span>
                    <span className="text-teal-700 font-bold">({doc.distanceKm} km away)</span>
                  </div>

                  <div className="flex items-center gap-4 text-xs text-gray-500 pt-1">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-gray-400" />
                      {doc.timings}
                    </span>
                    <span className="flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                      <strong className="text-gray-900">{doc.rating}</strong> ({doc.reviewsCount} reviews)
                    </span>
                    <span className="font-semibold text-gray-900">
                      Fee: ₹{doc.consultationFee}
                    </span>
                  </div>
                </div>

                <div className="flex sm:flex-col gap-2 w-full sm:w-auto flex-shrink-0">
                  <a
                    href={`tel:${doc.phone.replace(/[^0-9]/g, '')}`}
                    className="flex-1 sm:flex-none px-4 py-2 bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200 text-xs font-bold rounded-lg text-center flex items-center justify-center gap-1.5 transition"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call Clinic</span>
                  </a>
                  <button
                    onClick={() => setSelectedDoctor(doc)}
                    className="flex-1 sm:flex-none px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-lg text-center flex items-center justify-center gap-1.5 shadow-xs transition cursor-pointer"
                  >
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Book Visit</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Appointment Booking Modal */}
      {selectedDoctor && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-gray-100">
            <div className="bg-teal-700 text-white px-6 py-4 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base">Book Clinic Consultation</h3>
                <p className="text-xs text-teal-100">{selectedDoctor.name}</p>
              </div>
              <button
                onClick={() => setSelectedDoctor(null)}
                className="text-white/80 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {bookingSuccess ? (
              <div className="p-8 text-center space-y-3">
                <CheckCircle className="w-12 h-12 text-teal-600 mx-auto animate-bounce" />
                <h4 className="font-bold text-gray-900 text-lg">Appointment Confirmed!</h4>
                <p className="text-xs text-gray-600">
                  Your consultation request with <strong>{selectedDoctor.name}</strong> at{' '}
                  <strong>{selectedDoctor.clinicName}</strong> has been registered. You will receive an SMS reminder.
                </p>
              </div>
            ) : (
              <form onSubmit={handleBookSubmit} className="p-6 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Patient Full Name</label>
                  <input
                    type="text"
                    required
                    value={patientName}
                    onChange={e => setPatientName(e.target.value)}
                    placeholder="Enter patient name"
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Contact Phone</label>
                  <input
                    type="tel"
                    required
                    value={patientPhone}
                    onChange={e => setPatientPhone(e.target.value)}
                    placeholder="+91 98765 00000"
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">Preferred Date</label>
                    <input
                      type="date"
                      required
                      value={appointmentDate}
                      onChange={e => setAppointmentDate(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">Time Slot</label>
                    <select
                      value={appointmentSlot}
                      onChange={e => setAppointmentSlot(e.target.value)}
                      className="w-full px-2 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                    >
                      <option value="09:30 AM - 10:30 AM">09:30 AM - 10:30 AM</option>
                      <option value="11:00 AM - 12:00 PM">11:00 AM - 12:00 PM</option>
                      <option value="04:30 PM - 05:30 PM">04:30 PM - 05:30 PM</option>
                      <option value="06:30 PM - 07:30 PM">06:30 PM - 07:30 PM</option>
                    </select>
                  </div>
                </div>

                <div className="p-3 bg-gray-50 rounded-lg text-xs space-y-1 text-gray-600">
                  <div className="flex justify-between">
                    <span>Consultation Fee:</span>
                    <strong className="text-gray-900">₹{selectedDoctor.consultationFee}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Clinic Address:</span>
                    <span className="text-gray-900 truncate max-w-[200px]">{selectedDoctor.address}</span>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold rounded-lg shadow-sm transition"
                >
                  Confirm Appointment
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
