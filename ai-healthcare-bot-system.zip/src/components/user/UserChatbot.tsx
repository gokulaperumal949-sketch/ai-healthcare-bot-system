import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Bot,
  User as UserIcon,
  AlertTriangle,
  HeartPulse,
  Sparkles,
  PhoneCall,
  CheckCircle2,
  HelpCircle,
  RefreshCw,
  Cpu,
  Building2,
  Stethoscope
} from 'lucide-react';
import { ChatMessage, User } from '../../types';
import { ChatService, BotEngineMode } from '../../services/chatService';

interface UserChatbotProps {
  currentUser: User | null;
  onNavigateTab: (tab: 'doctors' | 'hospitals') => void;
}

export const UserChatbot: React.FC<UserChatbotProps> = ({
  currentUser,
  onNavigateTab,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: `Hello ${currentUser ? currentUser.name : 'there'}! I am **ArogyaBot**, your AI Healthcare Assistant powered by Python and Deep Learning (CNN).\n\nI can help evaluate symptoms, identify health risks, suggest instant precautions & first-aid, and guide you to nearby doctors and hospitals in emergencies.\n\n*What symptoms or health concerns are you experiencing today?*`,
      timestamp: new Date().toISOString(),
      source: 'cnn_model',
      urgency: 'low',
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [engineMode, setEngineMode] = useState<BotEngineMode>('hybrid');
  const [isListening, setIsListening] = useState(false);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Speech Recognition Setup
  useEffect(() => {
    if (typeof window !== 'undefined' && ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window)) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-IN'; // Indian English / general

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(prev => (prev ? `${prev} ${transcript}` : transcript));
        setIsListening(false);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, []);

  const toggleVoiceInput = () => {
    if (!recognitionRef.current) {
      alert('Voice recognition is not supported in this browser. Please type your query.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      setIsListening(true);
      try {
        recognitionRef.current.start();
      } catch (e) {
        setIsListening(false);
      }
    }
  };

  const handleSpeak = (msgId: string, text: string) => {
    if (!('speechSynthesis' in window)) return;

    if (speakingMessageId === msgId) {
      window.speechSynthesis.cancel();
      setSpeakingMessageId(null);
      return;
    }

    window.speechSynthesis.cancel();
    // Clean markdown before speaking
    const cleanText = text
      .replace(/[#*_`]/g, '')
      .replace(/\[.*?\]/g, '')
      .replace(/\n+/g, ' ');

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 0.95;
    utterance.onend = () => setSpeakingMessageId(null);
    utterance.onerror = () => setSpeakingMessageId(null);

    setSpeakingMessageId(msgId);
    window.speechSynthesis.speak(utterance);
  };

  const handleSend = async (overrideText?: string) => {
    const textToSend = (overrideText || input).trim();
    if (!textToSend || isLoading) return;

    const userMsg: ChatMessage = {
      id: 'msg-' + Date.now(),
      role: 'user',
      content: textToSend,
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await ChatService.sendMessage(
        textToSend,
        messages,
        currentUser,
        engineMode
      );
      setMessages(prev => [...prev, response]);
    } catch (error) {
      console.error('Chat error:', error);
      const fallbackMsg: ChatMessage = {
        id: 'msg-' + Date.now(),
        role: 'assistant',
        content: 'I encountered an issue processing your symptoms. Please visit the nearest hospital or doctor clinic in case of urgency.',
        timestamp: new Date().toISOString(),
        urgency: 'moderate',
      };
      setMessages(prev => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickSymptoms = [
    { label: 'Chest Pain & Arm Radiation', query: 'I have severe crushing chest pain radiating to left arm and cold sweat' },
    { label: 'High Fever & Chills', query: 'Sudden high fever with shivering chills, body ache and headache' },
    { label: 'Severe Breathing Trouble', query: 'Extreme wheezing, coughing, chest tightness and shortness of breath' },
    { label: 'Stomach Pain & Diarrhea', query: 'Severe abdominal cramps, watery loose motions and vomiting since morning' },
    { label: 'Throbbing Migraine', query: 'One-sided throbbing headache with light sensitivity and nausea' },
    { label: 'Skin Rash & Itching', query: 'Intense red itchy hives and swollen welts across skin' },
  ];

  const clearChat = () => {
    setMessages([
      {
        id: 'welcome-reset',
        role: 'assistant',
        content: `Chat history cleared. I am ready to evaluate any new symptoms or health questions.`,
        timestamp: new Date().toISOString(),
        source: 'cnn_model',
        urgency: 'low',
      },
    ]);
  };

  return (
    <div className="max-w-5xl mx-auto h-[calc(100vh-8.5rem)] flex flex-col bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
      {/* Top Header / Engine Mode Bar */}
      <div className="bg-gray-50 border-b border-gray-200 px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold">
            <HeartPulse className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-gray-900 leading-tight">
              Clinical Symptom Triage Bot
            </h2>
            <div className="flex items-center gap-2 text-[11px] text-gray-500">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                Active System
              </span>
              <span>•</span>
              <span>Python CNN Disease Classifier</span>
            </div>
          </div>
        </div>

        {/* Engine Mode Toggle */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-gray-500 font-medium hidden sm:inline">Engine:</span>
          <div className="bg-gray-200/80 p-0.5 rounded-lg flex items-center">
            <button
              onClick={() => setEngineMode('hybrid')}
              className={`px-2.5 py-1 rounded-md transition font-medium flex items-center gap-1.5 ${
                engineMode === 'hybrid'
                  ? 'bg-white text-teal-800 shadow-xs font-semibold'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
              title="Combines Gemini 3.8 Flash LLM clinical reasoning with local CNN classification"
            >
              <Sparkles className="w-3.5 h-3.5 text-teal-600" />
              <span>Hybrid (Gemini + CNN)</span>
            </button>
            <button
              onClick={() => setEngineMode('cnn_only')}
              className={`px-2.5 py-1 rounded-md transition font-medium flex items-center gap-1.5 ${
                engineMode === 'cnn_only'
                  ? 'bg-white text-purple-800 shadow-xs font-semibold'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
              title="Uses pure CNN Model and trained Medical Knowledge Base without external LLM"
            >
              <Cpu className="w-3.5 h-3.5 text-purple-600" />
              <span>Python CNN Only</span>
            </button>
          </div>

          <button
            onClick={clearChat}
            className="p-1.5 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-200 transition"
            title="Reset conversation"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Feed */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
        {messages.map(msg => {
          const isUser = msg.role === 'user';
          const isEmergency = msg.urgency === 'emergency';
          const isHigh = msg.urgency === 'high';

          return (
            <div
              key={msg.id}
              className={`flex gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div
                  className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-white ${
                    isEmergency ? 'bg-red-600' : 'bg-teal-600'
                  }`}
                >
                  {isEmergency ? <AlertTriangle className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>
              )}

              <div
                className={`max-w-[85%] sm:max-w-2xl rounded-2xl p-4 transition ${
                  isUser
                    ? 'bg-teal-700 text-white rounded-br-xs'
                    : isEmergency
                    ? 'bg-red-50/90 border-2 border-red-400 text-gray-900 rounded-bl-xs shadow-sm'
                    : 'bg-gray-50 border border-gray-200 text-gray-900 rounded-bl-xs'
                }`}
              >
                {/* Emergency Header if triggered */}
                {!isUser && isEmergency && (
                  <div className="mb-3 p-3 bg-red-600 text-white rounded-xl flex items-center justify-between shadow-xs">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5 text-amber-200 animate-bounce flex-shrink-0" />
                      <div>
                        <h4 className="font-bold text-xs sm:text-sm uppercase tracking-wide">
                          Emergency Medical Alert
                        </h4>
                        <p className="text-[11px] text-red-100">
                          Immediate hospital emergency or 108 ambulance dispatch required.
                        </p>
                      </div>
                    </div>
                    <a
                      href="tel:108"
                      className="px-3 py-1 bg-white text-red-700 font-bold text-xs rounded-lg shadow-xs hover:bg-red-50 transition flex items-center gap-1.5 flex-shrink-0"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      Call 108
                    </a>
                  </div>
                )}

                {/* CNN Disease Risk Prediction Pill */}
                {!isUser && msg.predictedDisease && (
                  <div className="mb-3 pb-3 border-b border-gray-200 flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-1.5">
                      <span className="font-semibold text-gray-700">Trained CNN Risk:</span>
                      <span className="font-bold text-teal-800 bg-teal-100/80 px-2 py-0.5 rounded">
                        {msg.predictedDisease}
                      </span>
                      {msg.confidenceScore && (
                        <span className="text-[11px] text-gray-500">
                          ({msg.confidenceScore}% confidence)
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[11px] font-bold uppercase px-2 py-0.5 rounded ${
                          isEmergency
                            ? 'bg-red-600 text-white'
                            : isHigh
                            ? 'bg-amber-100 text-amber-800'
                            : msg.urgency === 'moderate'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {msg.urgency || 'Routine'} Urgency
                      </span>
                    </div>
                  </div>
                )}

                {/* Message Body */}
                <div className={`prose prose-sm max-w-none text-xs sm:text-sm leading-relaxed whitespace-pre-wrap ${isUser ? 'text-white' : 'text-gray-800'}`}>
                  {msg.content}
                </div>

                {/* Suggested Facilities if attached */}
                {!isUser && msg.suggestedFacilities && msg.suggestedFacilities.length > 0 && (
                  <div className="mt-4 pt-3 border-t border-gray-200/80 space-y-2">
                    <p className="text-xs font-bold text-gray-700 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-teal-700" />
                      Nearby Recommended Facilities for this condition:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {msg.suggestedFacilities.map((fac, idx) => (
                        <div
                          key={idx}
                          className="p-2.5 rounded-lg bg-white border border-gray-200 text-xs flex flex-col justify-between"
                        >
                          <div>
                            <span className="font-semibold text-gray-900 block truncate">
                              {fac.name}
                            </span>
                            <span className="text-[11px] text-gray-500">
                              Approx. {fac.distanceKm} km away
                            </span>
                          </div>
                          <div className="mt-2 flex items-center justify-between pt-1 border-t border-gray-100">
                            <a
                              href={`tel:${fac.phone.replace(/[^0-9]/g, '')}`}
                              className="text-teal-700 font-semibold hover:underline flex items-center gap-1 text-[11px]"
                            >
                              <PhoneCall className="w-3 h-3" />
                              {fac.phone}
                            </a>
                            <button
                              onClick={() => onNavigateTab(fac.type === 'hospital' ? 'hospitals' : 'doctors')}
                              className="text-[11px] text-gray-500 hover:text-gray-900 font-medium underline"
                            >
                              View on Map
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Footer bar for bot response: TTS audio and source info */}
                {!isUser && (
                  <div className="mt-3 pt-2 border-t border-gray-200/60 flex items-center justify-between text-[11px] text-gray-400">
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleSpeak(msg.id, msg.content)}
                        className="hover:text-teal-700 flex items-center gap-1 transition"
                        title={speakingMessageId === msg.id ? 'Stop speaking' : 'Read aloud'}
                      >
                        {speakingMessageId === msg.id ? (
                          <>
                            <VolumeX className="w-3.5 h-3.5 text-red-500" />
                            <span className="text-red-500 font-medium">Stop audio</span>
                          </>
                        ) : (
                          <>
                            <Volume2 className="w-3.5 h-3.5" />
                            <span>Read aloud</span>
                          </>
                        )}
                      </button>
                    </div>

                    <span>
                      {msg.source === 'gemini_ai'
                        ? 'Gemini 3.8 Flash + CNN Triage'
                        : 'Python CNN Intent Classifier'}
                    </span>
                  </div>
                )}
              </div>

              {isUser && (
                <div className="w-8 h-8 rounded-full flex-shrink-0 bg-teal-800 text-white flex items-center justify-center font-bold text-xs">
                  {currentUser ? currentUser.name.charAt(0) : <UserIcon className="w-4 h-4" />}
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex gap-3 justify-start items-center">
            <div className="w-8 h-8 rounded-full bg-teal-600 text-white flex items-center justify-center">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-gray-50 border border-gray-200 rounded-2xl px-4 py-3 text-xs text-gray-600 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-teal-600 animate-ping"></span>
              <span>Analyzing symptom tokens through CNN disease prediction layers...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Symptom Chips */}
      <div className="px-4 py-2 bg-gray-50/80 border-t border-gray-100 overflow-x-auto">
        <div className="flex items-center gap-2 whitespace-nowrap text-xs">
          <span className="text-gray-400 font-medium flex items-center gap-1">
            <HelpCircle className="w-3.5 h-3.5" />
            Common Symptoms:
          </span>
          {quickSymptoms.map((s, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(s.query)}
              className="px-2.5 py-1 bg-white hover:bg-teal-50 hover:border-teal-300 border border-gray-200 rounded-full text-gray-700 transition cursor-pointer text-xs"
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Input Box */}
      <div className="p-3 sm:p-4 bg-white border-t border-gray-200">
        <form
          onSubmit={e => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2"
        >
          <button
            type="button"
            onClick={toggleVoiceInput}
            className={`p-2.5 rounded-xl border transition ${
              isListening
                ? 'bg-red-500 text-white border-red-600 animate-pulse'
                : 'bg-gray-100 text-gray-600 border-gray-200 hover:bg-gray-200'
            }`}
            title={isListening ? 'Listening... click to stop' : 'Click to speak symptoms'}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder={
              isListening
                ? 'Listening to your symptoms...'
                : 'Describe symptoms (e.g. fever with chills, chest tightness, headache)...'
            }
            className="flex-1 px-4 py-2.5 text-sm border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-teal-500 bg-gray-50/50"
          />

          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="px-4 sm:px-5 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-semibold rounded-xl shadow-xs transition flex items-center gap-2 cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">Send</span>
          </button>
        </form>
        <p className="text-[11px] text-gray-400 mt-1.5 text-center">
          In emergencies, immediately call 108 / 112 or visit the nearest trauma center. This system provides supportive guidance.
        </p>
      </div>
    </div>
  );
};
