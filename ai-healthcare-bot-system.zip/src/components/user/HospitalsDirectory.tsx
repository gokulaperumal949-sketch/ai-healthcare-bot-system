import React, { useState } from 'react';
import {
  Building2,
  PhoneCall,
  AlertTriangle,
  Ambulance,
  Bed,
  MapPin,
  Clock,
  ShieldAlert,
  Search,
  CheckCircle,
  Navigation2
} from 'lucide-react';
import { Hospital } from '../../types';
import { AppStorage } from '../../services/storage';

export const HospitalsDirectory: React.FC = () => {
  const [hospitals] = useState<Hospital[]>(() => AppStorage.getHospitals());
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('All');
  const [onlyEmergency, setOnlyEmergency] = useState(false);
  const [selectedHospital, setSelectedHospital] = useState<Hospital | null>(null);

  const types = ['All', 'Government', 'Private Multi-Specialty', 'Trauma Center', 'Primary Health Center (PHC)'];

  const filteredHospitals = hospitals.filter(h => {
    const matchesSearch =
      h.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      h.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
      h.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
      h.facilities.some(f => f.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesType = filterType === 'All' || h.type === filterType;
    const matchesEmergency = !onlyEmergency || h.has24x7Emergency;

    return matchesSearch && matchesType && matchesEmergency;
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-red-800 via-rose-900 to-red-950 rounded-2xl p-6 sm:p-8 text-white shadow-sm">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-700/80 text-amber-200 text-xs font-semibold mb-3 border border-red-600">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Emergency Medical & Trauma Directory</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Nearby Emergency Hospitals & Trauma Centers
          </h1>
          <p className="mt-2 text-rose-100 text-sm sm:text-base leading-relaxed">
            Locate 24x7 emergency casualty units, trauma centers, and government district hospitals. Check real-time ICU bed availability and dispatch emergency ambulance transport.
          </p>

          <div className="mt-4 flex flex-wrap items-center gap-3">
            <a
              href="tel:108"
              className="px-4 py-2 bg-white text-red-700 font-extrabold text-sm rounded-xl hover:bg-rose-50 transition shadow-md flex items-center gap-2"
            >
              <PhoneCall className="w-4 h-4 text-red-600" />
              <span>Call 108 Ambulance</span>
            </a>
            <a
              href="tel:112"
              className="px-4 py-2 bg-red-700 text-white font-bold text-sm rounded-xl hover:bg-red-600 border border-red-500 transition flex items-center gap-2"
            >
              <AlertTriangle className="w-4 h-4 text-amber-300" />
              <span>National SOS 112</span>
            </a>
          </div>
        </div>

        {/* Search bar */}
        <div className="mt-6 relative max-w-xl">
          <Search className="w-4 h-4 text-rose-300 absolute left-3 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search hospitals by name, trauma care, or medical facility..."
            className="w-full pl-9 pr-3 py-2.5 bg-red-950/70 border border-red-600/70 rounded-xl text-white placeholder-rose-300/70 text-sm focus:outline-none focus:ring-2 focus:ring-amber-300"
          />
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-x-auto py-1 text-xs">
          <span className="text-gray-400 font-medium">Hospital Category:</span>
          {types.map(t => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                filterType === t
                  ? 'bg-red-700 text-white font-semibold'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-3 text-xs">
          <label className="flex items-center gap-2 text-gray-700 font-medium cursor-pointer">
            <input
              type="checkbox"
              checked={onlyEmergency}
              onChange={e => setOnlyEmergency(e.target.checked)}
              className="rounded text-red-600 focus:ring-red-500"
            />
            <span className="font-semibold text-red-700">24x7 Emergency Casualty Only</span>
          </label>
        </div>
      </div>

      {/* Map Graphic & Hospital Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Visual Map Overview */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-gray-200 p-4 shadow-xs flex flex-col justify-between h-[480px] sticky top-20">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-gray-100 mb-3">
              <div className="flex items-center gap-2">
                <Navigation2 className="w-4 h-4 text-red-600" />
                <h3 className="font-bold text-sm text-gray-900">Hospital GPS Coordinates</h3>
              </div>
              <span className="text-xs text-red-700 font-medium bg-red-50 px-2 py-0.5 rounded">
                Live Dispatch Ready
              </span>
            </div>

            {/* Simulated Live Hospital Radar Map */}
            <div className="relative w-full h-72 rounded-lg overflow-hidden bg-slate-900 border border-slate-800 flex items-center justify-center p-4">
              {/* Radar rings */}
              <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#ef4444_1px,transparent_1px)] [background-size:20px_20px]"></div>
              <div className="w-56 h-56 rounded-full border border-red-500/20 absolute"></div>
              <div className="w-36 h-36 rounded-full border border-red-500/30 absolute"></div>
              <div className="w-16 h-16 rounded-full border border-red-500/40 absolute"></div>

              {/* Patient Pin */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center z-10">
                <div className="w-4 h-4 bg-teal-500 rounded-full border-2 border-white animate-ping"></div>
                <div className="w-4 h-4 bg-teal-500 rounded-full border-2 border-white absolute"></div>
                <span className="mt-2 text-[10px] font-bold bg-black/80 text-teal-300 px-1.5 py-0.5 rounded">
                  Patient Origin
                </span>
              </div>

              {/* Hospital Markers */}
              {filteredHospitals.map((hosp, idx) => {
                const offsets = [
                  { top: '30%', left: '25%' },
                  { top: '22%', left: '72%' },
                  { top: '75%', left: '30%' },
                  { top: '65%', left: '80%' },
                ];
                const pos = offsets[idx % offsets.length];

                return (
                  <button
                    key={hosp.id}
                    onClick={() => setSelectedHospital(hosp)}
                    style={{ top: pos.top, left: pos.left }}
                    className="absolute -translate-x-1/2 -translate-y-1/2 group z-20 cursor-pointer"
                  >
                    <div className="w-8 h-8 rounded-full bg-red-600 hover:bg-red-700 text-white flex items-center justify-center shadow-lg border-2 border-white transition transform group-hover:scale-110">
                      <Building2 className="w-4 h-4" />
                    </div>
                    <span className="opacity-0 group-hover:opacity-100 transition absolute -bottom-5 left-1/2 -translate-x-1/2 whitespace-nowrap bg-gray-900 text-white text-[10px] px-2 py-0.5 rounded shadow-lg pointer-events-none">
                      {hosp.name.slice(0, 24)} ({hosp.distanceKm} km)
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="mt-3 p-3 bg-red-50 rounded-lg text-xs text-red-900 border border-red-200">
            <p className="font-semibold flex items-center gap-1.5">
              <Ambulance className="w-4 h-4 text-red-700" />
              108 Ambulance Dispatch Link
            </p>
            <p className="text-[11px] text-red-800/80 mt-0.5">
              Nearest facility to current location: <strong>District Civil Hospital (1.5 km away)</strong>. Estimated transit: 6 mins.
            </p>
          </div>
        </div>

        {/* Hospital Cards List */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between text-xs text-gray-500">
            <span>Showing {filteredHospitals.length} emergency hospital facilities</span>
            <span>Sorted by proximity</span>
          </div>

          {filteredHospitals.map(hosp => (
            <div
              key={hosp.id}
              className="bg-white rounded-xl border border-gray-200 p-5 shadow-xs hover:border-red-300 transition flex flex-col justify-between space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-gray-900 text-base">{hosp.name}</h3>
                    {hosp.has24x7Emergency && (
                      <span className="text-[10px] font-bold text-red-700 bg-red-50 border border-red-200 px-2 py-0.5 rounded">
                        24x7 Emergency
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-red-700 font-semibold">{hosp.type}</p>
                </div>

                <div className="flex items-center gap-3 text-xs flex-shrink-0">
                  <div className="px-2.5 py-1 bg-gray-50 border border-gray-200 rounded-lg text-center">
                    <span className="text-[10px] text-gray-400 block font-medium">Distance</span>
                    <strong className="text-gray-900 font-bold">{hosp.distanceKm} km</strong>
                  </div>
                  <div className="px-2.5 py-1 bg-emerald-50 border border-emerald-200 rounded-lg text-center">
                    <span className="text-[10px] text-emerald-700 block font-medium">ICU Beds</span>
                    <strong className="text-emerald-800 font-bold">{hosp.icuBedsAvailable} Available</strong>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1.5 text-xs text-gray-600">
                <MapPin className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                <span>{hosp.address}, {hosp.city}</span>
              </div>

              {/* Facility Tags */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {hosp.facilities.map((fac, idx) => (
                  <span
                    key={idx}
                    className="text-[11px] font-medium bg-gray-100 text-gray-700 px-2 py-0.5 rounded"
                  >
                    {fac}
                  </span>
                ))}
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-gray-100 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-gray-400" />
                    Open 24 Hours
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Bed className="w-3.5 h-3.5 text-gray-400" />
                    {hosp.totalBeds} Total Beds
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={`tel:${hosp.phone.replace(/[^0-9]/g, '')}`}
                    className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs font-semibold rounded-lg transition"
                  >
                    Call Reception
                  </a>
                  <a
                    href={`tel:${hosp.emergencyPhone.replace(/[^0-9]/g, '')}`}
                    className="px-3.5 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg shadow-xs transition flex items-center gap-1.5"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>Emergency: {hosp.emergencyPhone}</span>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
