import React, { useState } from 'react';
import {
  User as UserIcon,
  Mail,
  Phone,
  Lock,
  HeartPulse,
  Save,
  CheckCircle2,
  Shield,
  AlertCircle,
  FileText
} from 'lucide-react';
import { User } from '../../types';
import { AppStorage } from '../../services/storage';

interface UserProfileProps {
  currentUser: User | null;
  onUpdateUser: (updated: User) => void;
}

export const UserProfile: React.FC<UserProfileProps> = ({
  currentUser,
  onUpdateUser,
}) => {
  if (!currentUser) {
    return (
      <div className="max-w-xl mx-auto p-8 text-center bg-white rounded-xl border border-gray-200">
        <UserIcon className="w-12 h-12 text-gray-400 mx-auto mb-3" />
        <h3 className="font-bold text-gray-900 text-lg">No Active User Session</h3>
        <p className="text-xs text-gray-500 mt-1">Please sign in to view and manage your profile.</p>
      </div>
    );
  }

  const [name, setName] = useState(currentUser.name);
  const [phone, setPhone] = useState(currentUser.phone || '');
  const [age, setAge] = useState<number | ''>(currentUser.age ?? 28);
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>(currentUser.gender || 'Male');
  const [bloodGroup, setBloodGroup] = useState(currentUser.bloodGroup || 'O+');
  const [allergies, setAllergies] = useState(currentUser.allergies || '');
  const [medicalHistory, setMedicalHistory] = useState(currentUser.medicalHistory || '');
  const [emergencyContact, setEmergencyContact] = useState(currentUser.emergencyContact || '');

  // Password fields
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordMsg, setPasswordMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const [profileSaved, setProfileSaved] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();

    const updated: User = {
      ...currentUser,
      name: name.trim(),
      phone: phone.trim(),
      age: typeof age === 'number' ? age : undefined,
      gender,
      bloodGroup,
      allergies: allergies.trim(),
      medicalHistory: medicalHistory.trim(),
      emergencyContact: emergencyContact.trim(),
    };

    // Update in stored users
    const allUsers = AppStorage.getUsers();
    const updatedUsers = allUsers.map(u => (u.id === updated.id ? updated : u));
    AppStorage.saveUsers(updatedUsers);
    AppStorage.setCurrentUser(updated);
    onUpdateUser(updated);

    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 3000);
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordMsg(null);

    if (!newPassword || newPassword.length < 6) {
      setPasswordMsg({ type: 'error', text: 'New password must be at least 6 characters long.' });
      return;
    }

    if (newPassword !== confirmPassword) {
      setPasswordMsg({ type: 'error', text: 'New password and confirmation do not match.' });
      return;
    }

    // Success simulation
    setPasswordMsg({ type: 'success', text: 'Password successfully updated and securely hashed!' });
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setTimeout(() => setPasswordMsg(null), 4000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Title */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Patient Health Profile</h1>
          <p className="text-xs text-gray-500">Manage personal demographics, clinical history, and account password.</p>
        </div>
        <span className="text-xs font-semibold px-2.5 py-1 rounded bg-teal-50 text-teal-800 border border-teal-200">
          User ID: {currentUser.id}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left Column: Profile Form */}
        <div className="md:col-span-8 bg-white rounded-xl border border-gray-200 p-6 shadow-xs space-y-6">
          <form onSubmit={handleSaveProfile} className="space-y-4">
            <h2 className="text-sm font-bold text-gray-900 flex items-center gap-2 pb-2 border-b border-gray-100">
              <UserIcon className="w-4 h-4 text-teal-700" />
              <span>Personal & Medical Information</span>
            </h2>

            {profileSaved && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-2 text-xs text-emerald-800">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span>Profile details have been updated successfully!</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Full Legal Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Email Address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                  <input
                    type="email"
                    disabled
                    value={currentUser.email}
                    className="w-full pl-9 pr-3 py-2 text-sm border border-gray-200 bg-gray-50 text-gray-500 rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Phone Number</label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Age</label>
                <input
                  type="number"
                  min="1"
                  max="120"
                  value={age}
                  onChange={e => setAge(e.target.value ? Number(e.target.value) : '')}
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Gender</label>
                <select
                  value={gender}
                  onChange={e => setGender(e.target.value as any)}
                  className="w-full px-2 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Blood Group</label>
                <select
                  value={bloodGroup}
                  onChange={e => setBloodGroup(e.target.value)}
                  className="w-full px-2 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                >
                  <option value="A+">A+</option>
                  <option value="A-">A-</option>
                  <option value="B+">B+</option>
                  <option value="B-">B-</option>
                  <option value="O+">O+</option>
                  <option value="O-">O-</option>
                  <option value="AB+">AB+</option>
                  <option value="AB-">AB-</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Known Drug / Food Allergies
              </label>
              <input
                type="text"
                value={allergies}
                onChange={e => setAllergies(e.target.value)}
                placeholder="e.g. Penicillin, Peanuts, Sulfa drugs"
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Medical History / Chronic Conditions
              </label>
              <textarea
                rows={2}
                value={medicalHistory}
                onChange={e => setMedicalHistory(e.target.value)}
                placeholder="e.g. Type 2 Diabetes, Hypertension, Childhood asthma"
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">
                Emergency Contact Person & Phone
              </label>
              <input
                type="text"
                value={emergencyContact}
                onChange={e => setEmergencyContact(e.target.value)}
                placeholder="e.g. Anjali (Spouse) +91 98765 11111"
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-lg shadow-xs transition flex items-center gap-2 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save Profile Updates</span>
            </button>
          </form>

          {/* Change Password Form (Project Requirement) */}
          <div className="pt-6 border-t border-gray-100 space-y-4">
            <h2 className="text-sm font-bold text-gray-900 flex items-center gap-2">
              <Lock className="w-4 h-4 text-teal-700" />
              <span>Change Password</span>
            </h2>

            {passwordMsg && (
              <div
                className={`p-3 rounded-lg flex items-center gap-2 text-xs ${
                  passwordMsg.type === 'success'
                    ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                    : 'bg-red-50 border border-red-200 text-red-800'
                }`}
              >
                {passwordMsg.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0" />
                )}
                <span>{passwordMsg.text}</span>
              </div>
            )}

            <form onSubmit={handleChangePassword} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Current Password</label>
                <input
                  type="password"
                  required
                  value={currentPassword}
                  onChange={e => setCurrentPassword(e.target.value)}
                  placeholder="Enter current password"
                  className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">New Password</label>
                  <input
                    type="password"
                    required
                    value={newPassword}
                    onChange={e => setNewPassword(e.target.value)}
                    placeholder="Minimum 6 characters"
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Confirm New Password</label>
                  <input
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={e => setConfirmPassword(e.target.value)}
                    placeholder="Repeat new password"
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="px-4 py-2 bg-gray-800 hover:bg-gray-900 text-white text-xs font-bold rounded-lg transition flex items-center gap-2 cursor-pointer"
              >
                <Shield className="w-3.5 h-3.5" />
                <span>Update Password</span>
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: Emergency Medical Card */}
        <div className="md:col-span-4 space-y-4">
          <div className="bg-gradient-to-br from-red-700 to-rose-900 text-white rounded-2xl p-5 shadow-md space-y-4 border border-red-600">
            <div className="flex items-center justify-between border-b border-red-600/80 pb-3">
              <div className="flex items-center gap-2">
                <HeartPulse className="w-5 h-5 text-amber-300" />
                <h3 className="font-extrabold text-sm uppercase tracking-wider">
                  Emergency Medical Card
                </h3>
              </div>
              <span className="text-[10px] bg-red-950/60 px-2 py-0.5 rounded font-mono">
                {currentUser.bloodGroup || 'O+'}
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div>
                <span className="text-red-200 block text-[10px]">Patient Name</span>
                <strong className="text-sm font-bold text-white">{name}</strong>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <div>
                  <span className="text-red-200 block text-[10px]">Blood Group</span>
                  <span className="font-semibold text-white">{bloodGroup}</span>
                </div>
                <div>
                  <span className="text-red-200 block text-[10px]">Age / Gender</span>
                  <span className="font-semibold text-white">{age || 'N/A'} / {gender}</span>
                </div>
              </div>

              <div className="pt-1">
                <span className="text-red-200 block text-[10px]">Known Allergies</span>
                <span className="font-semibold text-amber-200">{allergies || 'None recorded'}</span>
              </div>

              <div className="pt-1">
                <span className="text-red-200 block text-[10px]">Emergency SOS Contact</span>
                <span className="font-semibold text-white">{emergencyContact || phone}</span>
              </div>
            </div>

            <div className="pt-3 border-t border-red-600/80 flex items-center justify-between text-[11px] text-red-200">
              <span>National SOS: 108 / 112</span>
              <span>ArogyaBot ID</span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-xs text-xs space-y-2">
            <h4 className="font-bold text-gray-900 flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-teal-700" />
              <span>Digital Health Records Privacy</span>
            </h4>
            <p className="text-gray-500 leading-relaxed">
              Your clinical profile is stored locally in client-side secure sandbox and synchronized with your local health session. When you consult ArogyaBot, allergy flags and existing conditions are evaluated to ensure safe triage.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
