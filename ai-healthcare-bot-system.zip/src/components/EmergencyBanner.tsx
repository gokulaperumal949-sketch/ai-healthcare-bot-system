import React, { useState } from 'react';
import { PhoneCall, AlertTriangle, X, ShieldAlert, HeartPulse } from 'lucide-react';

export const EmergencyBanner: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const emergencyContacts = [
    { label: 'National Emergency', number: '112', desc: 'All-in-one Emergency Services' },
    { label: 'Ambulance (Toll-Free)', number: '108', desc: 'Free Emergency Medical & Trauma Transport' },
    { label: 'Maternal & Child Care', number: '102', desc: 'Pregnant Women & Newborn Infant Transport' },
    { label: 'National Health Helpline', number: '1075', desc: 'Government Medical Information & Triage' },
    { label: 'Poison Control Centre', number: '1800-116-117', desc: 'AIIMS National Poison Information' }
  ];

  return (
    <>
      <div className="bg-red-700 text-white px-4 py-2 text-xs md:text-sm font-medium flex items-center justify-between shadow-sm">
        <div className="flex items-center space-x-2">
          <AlertTriangle className="w-4 h-4 animate-pulse text-amber-300 flex-shrink-0" />
          <span>
            <strong>Emergency Alert:</strong> In case of acute chest pain, severe breathing difficulty, or trauma, call <strong>108 / 112</strong> immediately.
          </span>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setIsOpen(true)}
            className="bg-white text-red-700 px-3 py-1 rounded text-xs font-semibold hover:bg-red-50 transition cursor-pointer flex items-center gap-1"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>Emergency Helplines</span>
          </button>
        </div>
      </div>

      {isOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden border border-red-200">
            <div className="bg-red-700 text-white px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-6 h-6 text-amber-300" />
                <h3 className="font-bold text-lg">National Emergency Medical Numbers</h3>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="text-white/80 hover:text-white p-1 rounded-md hover:bg-red-800 transition"
                aria-label="Close emergency modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <p className="text-sm text-gray-600">
                These hotlines operate 24x7 across India and connect you directly to nearest dispatchers, ambulances, and trauma response units.
              </p>

              <div className="space-y-2.5">
                {emergencyContacts.map(c => (
                  <div key={c.number} className="flex items-center justify-between p-3 rounded-lg border border-gray-100 bg-gray-50 hover:bg-red-50 hover:border-red-200 transition">
                    <div>
                      <h4 className="font-semibold text-gray-900 text-sm flex items-center gap-1.5">
                        <HeartPulse className="w-4 h-4 text-red-600" />
                        {c.label}
                      </h4>
                      <p className="text-xs text-gray-500">{c.desc}</p>
                    </div>
                    <a
                      href={`tel:${c.number.replace(/[^0-9]/g, '')}`}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-red-600 text-white text-sm font-bold rounded-lg hover:bg-red-700 transition"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      {c.number}
                    </a>
                  </div>
                ))}
              </div>

              <div className="mt-4 pt-4 border-t border-gray-100 flex justify-between items-center text-xs text-gray-500">
                <span>Free Service • Available 24x7</span>
                <button
                  onClick={() => setIsOpen(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-100 transition"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
