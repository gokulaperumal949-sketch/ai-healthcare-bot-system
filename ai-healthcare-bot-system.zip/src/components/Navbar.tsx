import React from 'react';
import { Bot, User as UserIcon, Building2, Stethoscope, ShieldCheck, Code, LogOut, ChevronDown } from 'lucide-react';
import { User } from '../types';

export type ActiveTab = 'chat' | 'doctors' | 'hospitals' | 'profile' | 'admin' | 'architecture';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  currentUser: User | null;
  onOpenAuth: () => void;
  onLogout: () => void;
  onSwitchRole: (targetRole: 'user' | 'admin') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  onOpenAuth,
  onLogout,
  onSwitchRole
}) => {
  const isAdmin = currentUser?.role === 'admin';

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-40 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Project Title */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('chat')}>
            <div className="w-10 h-10 rounded-xl bg-teal-600 flex items-center justify-center text-white shadow-sm">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-gray-900 tracking-tight text-lg">ArogyaBot AI</span>
                <span className="text-[11px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded bg-teal-50 text-teal-700 border border-teal-200">
                  Python & CNN
                </span>
              </div>
              <p className="text-xs text-gray-500 hidden sm:block">AI Healthcare Bot System</p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
            <button
              onClick={() => setActiveTab('chat')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition ${
                activeTab === 'chat'
                  ? 'bg-teal-50 text-teal-800 font-semibold'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              <Bot className="w-4 h-4 text-teal-600" />
              <span>Chat with Bot</span>
            </button>

            <button
              onClick={() => setActiveTab('doctors')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition ${
                activeTab === 'doctors'
                  ? 'bg-teal-50 text-teal-800 font-semibold'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              <Stethoscope className="w-4 h-4 text-blue-600" />
              <span>Doctors & Clinics</span>
            </button>

            <button
              onClick={() => setActiveTab('hospitals')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition ${
                activeTab === 'hospitals'
                  ? 'bg-teal-50 text-teal-800 font-semibold'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              <Building2 className="w-4 h-4 text-red-600" />
              <span>Nearby Hospitals</span>
            </button>

            <button
              onClick={() => setActiveTab('profile')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition ${
                activeTab === 'profile'
                  ? 'bg-teal-50 text-teal-800 font-semibold'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              <UserIcon className="w-4 h-4 text-gray-600" />
              <span>Profile</span>
            </button>

            <button
              onClick={() => setActiveTab('admin')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition ${
                activeTab === 'admin'
                  ? 'bg-purple-50 text-purple-800 font-semibold'
                  : 'text-purple-700 hover:bg-purple-50'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-purple-600" />
              <span>Admin Module</span>
            </button>

            <button
              onClick={() => setActiveTab('architecture')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition ${
                activeTab === 'architecture'
                  ? 'bg-amber-50 text-amber-900 font-semibold'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
              title="Python Django CNN Architecture & Project Code"
            >
              <Code className="w-4 h-4 text-amber-600" />
              <span>Python & CNN Code</span>
            </button>
          </nav>

          {/* User Account & Role Switcher */}
          <div className="flex items-center gap-2">
            {currentUser ? (
              <div className="flex items-center gap-2">
                <div className="relative group">
                  <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-gray-200 hover:border-gray-300 bg-gray-50 text-left text-xs sm:text-sm">
                    <div className="w-7 h-7 rounded-full bg-teal-100 text-teal-800 flex items-center justify-center font-bold">
                      {currentUser.name.charAt(0)}
                    </div>
                    <div className="hidden sm:block">
                      <div className="font-semibold text-gray-900 leading-tight truncate max-w-[130px]">
                        {currentUser.name}
                      </div>
                      <div className="text-[10px] text-gray-500 font-medium">
                        {currentUser.role === 'admin' ? 'Administrator' : 'Registered Patient'}
                      </div>
                    </div>
                    <ChevronDown className="w-3.5 h-3.5 text-gray-500" />
                  </button>

                  {/* Dropdown Menu */}
                  <div className="absolute right-0 mt-1 w-56 bg-white border border-gray-200 rounded-xl shadow-lg p-1.5 hidden group-hover:block z-50">
                    <div className="px-3 py-2 border-b border-gray-100 mb-1">
                      <p className="text-xs font-semibold text-gray-900">{currentUser.name}</p>
                      <p className="text-[11px] text-gray-500 truncate">{currentUser.email}</p>
                    </div>

                    {isAdmin ? (
                      <button
                        onClick={() => onSwitchRole('user')}
                        className="w-full text-left px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 rounded-lg flex items-center gap-2"
                      >
                        <UserIcon className="w-3.5 h-3.5 text-teal-600" />
                        <span>Switch to Patient View</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => onSwitchRole('admin')}
                        className="w-full text-left px-3 py-2 text-xs text-purple-700 hover:bg-purple-50 rounded-lg flex items-center gap-2 font-medium"
                      >
                        <ShieldCheck className="w-3.5 h-3.5 text-purple-600" />
                        <span>Switch to Admin View</span>
                      </button>
                    )}

                    <button
                      onClick={() => setActiveTab('profile')}
                      className="w-full text-left px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 rounded-lg flex items-center gap-2"
                    >
                      <UserIcon className="w-3.5 h-3.5 text-gray-500" />
                      <span>Manage Profile & Password</span>
                    </button>

                    <div className="border-t border-gray-100 my-1"></div>

                    <button
                      onClick={onLogout}
                      className="w-full text-left px-3 py-2 text-xs text-red-600 hover:bg-red-50 rounded-lg flex items-center gap-2"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <button
                onClick={onOpenAuth}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs sm:text-sm font-semibold rounded-lg shadow-sm transition"
              >
                Sign In / Register
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-gray-100 text-xs overflow-x-auto">
          <button
            onClick={() => setActiveTab('chat')}
            className={`px-2 py-1 flex flex-col items-center ${activeTab === 'chat' ? 'text-teal-700 font-bold' : 'text-gray-500'}`}
          >
            <Bot className="w-4 h-4 mb-0.5" />
            <span>Chat</span>
          </button>
          <button
            onClick={() => setActiveTab('doctors')}
            className={`px-2 py-1 flex flex-col items-center ${activeTab === 'doctors' ? 'text-teal-700 font-bold' : 'text-gray-500'}`}
          >
            <Stethoscope className="w-4 h-4 mb-0.5" />
            <span>Doctors</span>
          </button>
          <button
            onClick={() => setActiveTab('hospitals')}
            className={`px-2 py-1 flex flex-col items-center ${activeTab === 'hospitals' ? 'text-teal-700 font-bold' : 'text-gray-500'}`}
          >
            <Building2 className="w-4 h-4 mb-0.5" />
            <span>Hospitals</span>
          </button>
          <button
            onClick={() => setActiveTab('admin')}
            className={`px-2 py-1 flex flex-col items-center ${activeTab === 'admin' ? 'text-purple-700 font-bold' : 'text-gray-500'}`}
          >
            <ShieldCheck className="w-4 h-4 mb-0.5" />
            <span>Admin</span>
          </button>
          <button
            onClick={() => setActiveTab('architecture')}
            className={`px-2 py-1 flex flex-col items-center ${activeTab === 'architecture' ? 'text-amber-700 font-bold' : 'text-gray-500'}`}
          >
            <Code className="w-4 h-4 mb-0.5" />
            <span>Python</span>
          </button>
        </div>
      </div>
    </header>
  );
};
