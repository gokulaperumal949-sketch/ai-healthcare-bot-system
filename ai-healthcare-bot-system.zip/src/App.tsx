import React, { useState, useEffect } from 'react';
import { EmergencyBanner } from './components/EmergencyBanner';
import { Navbar, ActiveTab } from './components/Navbar';
import { UserChatbot } from './components/user/UserChatbot';
import { DoctorsDirectory } from './components/user/DoctorsDirectory';
import { HospitalsDirectory } from './components/user/HospitalsDirectory';
import { UserProfile } from './components/user/UserProfile';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { PythonArchitectureView } from './components/python/PythonArchitectureView';
import { AuthModal } from './components/auth/AuthModal';
import { User } from './types';
import { AppStorage } from './services/storage';
import { HeartPulse, ShieldAlert, Cpu, Stethoscope } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('chat');
  const [currentUser, setCurrentUser] = useState<User | null>(() => AppStorage.getCurrentUser());
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  useEffect(() => {
    // If not logged in, auto-seed default user
    if (!currentUser) {
      const def = AppStorage.getCurrentUser();
      setCurrentUser(def);
    }
  }, [currentUser]);

  const handleLogout = () => {
    AppStorage.setCurrentUser(null);
    setCurrentUser(null);
    setIsAuthOpen(true);
  };

  const handleSwitchRole = (targetRole: 'user' | 'admin') => {
    const users = AppStorage.getUsers();
    if (targetRole === 'admin') {
      const admin = users.find(u => u.role === 'admin') || {
        id: 'admin-1',
        name: 'Dr. Suresh Varma (Lead Admin)',
        email: 'admin@healthbot.ai',
        phone: '+91 94444 88888',
        role: 'admin' as const,
        createdAt: new Date().toISOString(),
      };
      AppStorage.setCurrentUser(admin);
      setCurrentUser(admin);
      setActiveTab('admin');
    } else {
      const patient = users.find(u => u.role === 'user') || users[0];
      AppStorage.setCurrentUser(patient);
      setCurrentUser(patient);
      setActiveTab('chat');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-gray-900 selection:bg-teal-100 selection:text-teal-900">
      {/* 24x7 Emergency SOS Notice */}
      <EmergencyBanner />

      {/* Main Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthOpen(true)}
        onLogout={handleLogout}
        onSwitchRole={handleSwitchRole}
      />

      {/* App Body Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'chat' && (
          <UserChatbot
            currentUser={currentUser}
            onNavigateTab={tab => setActiveTab(tab)}
          />
        )}

        {activeTab === 'doctors' && <DoctorsDirectory />}

        {activeTab === 'hospitals' && <HospitalsDirectory />}

        {activeTab === 'profile' && (
          <UserProfile
            currentUser={currentUser}
            onUpdateUser={updated => setCurrentUser(updated)}
          />
        )}

        {activeTab === 'admin' && (
          <AdminDashboard
            currentUser={currentUser}
            onOpenAuth={() => setIsAuthOpen(true)}
          />
        )}

        {activeTab === 'architecture' && <PythonArchitectureView />}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12 py-8 text-xs text-gray-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-teal-600 flex items-center justify-center text-white">
                <HeartPulse className="w-4 h-4" />
              </div>
              <span className="font-bold text-gray-800">ArogyaBot AI Healthcare Bot System</span>
              <span className="text-gray-400">·</span>
              <span>Python & Deep Learning (CNN) Project</span>
            </div>

            <div className="flex items-center gap-4 text-xs">
              <button
                onClick={() => setActiveTab('architecture')}
                className="hover:text-teal-700 font-medium transition"
              >
                Python Django Specs
              </button>
              <button
                onClick={() => handleSwitchRole(currentUser?.role === 'admin' ? 'user' : 'admin')}
                className="hover:text-purple-700 font-medium transition"
              >
                {currentUser?.role === 'admin' ? 'Switch to Patient' : 'Switch to Admin'}
              </button>
              <button
                onClick={() => setActiveTab('hospitals')}
                className="text-red-600 font-bold hover:underline"
              >
                108 Emergency
              </button>
            </div>
          </div>

          <div className="border-t border-gray-100 pt-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-gray-400">
            <p>
              Developed to address healthcare inaccessibility and transport delays in rural and urban communities.
            </p>
            <p>
              Disclaimer: ArogyaBot provides AI clinical symptom triage and emergency routing. Consult a licensed physician for diagnosis.
            </p>
          </div>
        </div>
      </footer>

      {/* Sign In & Registration Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onSuccess={user => {
          setCurrentUser(user);
          if (user.role === 'admin') setActiveTab('admin');
        }}
      />
    </div>
  );
}
