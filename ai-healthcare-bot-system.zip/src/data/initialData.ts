import { Doctor, Hospital, QAItem, User, ModelMetrics } from '../types';

export const INITIAL_USERS: User[] = [
  {
    id: 'usr-1',
    name: 'Gokul Perumal',
    email: 'gokul@example.com',
    phone: '+91 98765 43210',
    role: 'user',
    age: 28,
    gender: 'Male',
    bloodGroup: 'O+',
    allergies: 'Penicillin, Dust mites',
    medicalHistory: 'Mild seasonal asthma, No surgical history',
    emergencyContact: '+91 98765 11111 (Father)',
    createdAt: '2026-01-15T09:30:00Z',
  },
  {
    id: 'usr-2',
    name: 'Ananya Sharma',
    email: 'ananya@example.com',
    phone: '+91 91234 56789',
    role: 'user',
    age: 34,
    gender: 'Female',
    bloodGroup: 'B+',
    allergies: 'None',
    medicalHistory: 'Occasional migraine, Gestational diabetes (resolved)',
    emergencyContact: '+91 91234 99999 (Spouse)',
    createdAt: '2026-02-02T11:20:00Z',
  },
  {
    id: 'usr-3',
    name: 'Rajesh Kumar',
    email: 'rajesh@example.com',
    phone: '+91 99887 76655',
    role: 'user',
    age: 52,
    gender: 'Male',
    bloodGroup: 'A+',
    allergies: 'Sulfa drugs',
    medicalHistory: 'Type 2 Diabetes, Hypertension (on Telmisartan 40mg)',
    emergencyContact: '+91 99887 00000 (Son)',
    createdAt: '2026-03-10T14:45:00Z',
  },
  {
    id: 'admin-1',
    name: 'Dr. Suresh Varma (Lead Admin)',
    email: 'admin@healthbot.ai',
    phone: '+91 94444 88888',
    role: 'admin',
    createdAt: '2026-01-01T00:00:00Z',
  }
];

export const INITIAL_QA_ITEMS: QAItem[] = [
  {
    id: 'qa-1',
    category: 'Cardiology',
    disease: 'Angina / Acute Coronary Syndrome',
    symptoms: ['chest pain', 'tightness in chest', 'pain radiating to left arm', 'jaw pain', 'sweating', 'shortness of breath'],
    keywords: ['chest', 'heart', 'arm pain', 'tightness', 'angina', 'attack', 'pressure in chest', 'cold sweat'],
    answer: 'Sudden tight crushing chest pain, especially radiating to the left shoulder, arm, or jaw accompanied by cold sweats and shortness of breath, may indicate Acute Coronary Syndrome or a Heart Attack.',
    precautions: [
      'Stop all physical activity immediately and sit upright in a comfortable position.',
      'Loosen any tight clothing around the neck and waist.',
      'If prescribed, take sublingual Nitroglycerin under medical guidance.',
      'DO NOT drive yourself; call for an ambulance immediately.',
      'Chew an uncoated Aspirin (300mg) if advised by emergency operators and not allergic.'
    ],
    urgency: 'emergency',
    homeRemedies: ['Keep patient calm', 'Ensure ample ventilation while waiting for ambulance'],
    whenToSeeDoctor: 'IMMEDIATE EMERGENCY: Call 108 / 112 without delay.',
    updatedAt: '2026-03-01T10:00:00Z'
  },
  {
    id: 'qa-2',
    category: 'Infectious Diseases',
    disease: 'Dengue Viral Fever',
    symptoms: ['high fever', 'severe headache', 'pain behind eyes', 'joint and muscle pain', 'nausea', 'skin rash'],
    keywords: ['dengue', 'mosquito', 'breakbone', 'behind eyes', 'high fever', 'platelets', 'body ache'],
    answer: 'Dengue is a mosquito-borne viral infection caused by the Aedes mosquito. Symptoms include sudden high fever (104°F), severe retro-orbital (behind the eye) headache, severe musculoskeletal "breakbone" aches, and rash.',
    precautions: [
      'Maintain rigorous hydration with Oral Rehydration Salts (ORS), coconut water, and fluids.',
      'Take Paracetamol for fever management as advised.',
      'STRICTLY AVOID NSAIDs like Ibuprofen or Aspirin as they increase hemorrhage/bleeding risks.',
      'Monitor platelet count via daily Complete Blood Count (CBC) test.',
      'Use mosquito nets and repellents to prevent transmission.'
    ],
    urgency: 'high',
    homeRemedies: ['Fresh coconut water', 'Papaya leaf extract fluid (adjunct)', 'Rest in cool room'],
    whenToSeeDoctor: 'Consult a physician within 24 hours. Seek emergency care if bleeding gums, black stool, or persistent vomiting occur.',
    updatedAt: '2026-03-02T12:00:00Z'
  },
  {
    id: 'qa-3',
    category: 'Infectious Diseases',
    disease: 'Malaria',
    symptoms: ['cyclical fever', 'shivering chills', 'heavy sweating', 'fatigue', 'headache'],
    keywords: ['malaria', 'chills', 'shivering', 'sweating', 'anopheles', 'cyclical fever'],
    answer: 'Malaria is caused by Plasmodium parasites transmitted by Anopheles mosquitoes. Classic presentation features cyclical paroxysms of intense shivering chills followed by high fever and profuse drenching sweats.',
    precautions: [
      'Get a rapid diagnostic test (RDT) or peripheral blood smear immediately.',
      'Complete the full course of prescribed Antimalarial medications (e.g., Artemisinin-based combinations).',
      'Hydrate adequately to avoid dehydration during peak fevers.',
      'Eliminate stagnant water around living quarters.'
    ],
    urgency: 'high',
    homeRemedies: ['Cool sponge compresses for fever spikes', 'Light digestible porridge', 'Ample fluids'],
    whenToSeeDoctor: 'Visit nearest primary health center or clinic within 12-24 hours for confirmatory blood film.',
    updatedAt: '2026-02-28T08:30:00Z'
  },
  {
    id: 'qa-4',
    category: 'Gastroenterology',
    disease: 'Acute Gastroenteritis / Food Poisoning',
    symptoms: ['watery diarrhea', 'stomach cramps', 'nausea', 'vomiting', 'mild fever', 'dehydration'],
    keywords: ['loose motion', 'vomiting', 'diarrhea', 'stomach ache', 'food poisoning', 'cramps', 'indigestion'],
    answer: 'Acute gastroenteritis is an inflammation of the stomach and intestines commonly caused by viral or bacterial contamination of food or water, leading to rapid fluid loss.',
    precautions: [
      'Prioritize rehydration: Sip WHO-formulated ORS steadily after every loose stool.',
      'Follow the BRAT diet (Bananas, Rice, Applesauce, Toast) once vomiting subsides.',
      'Avoid milk, dairy, caffeine, spicy, oily, or raw foods for 48 hours.',
      'Wash hands thoroughly with soap before eating and after toilet use.'
    ],
    urgency: 'moderate',
    homeRemedies: ['Rice gruel with salt', 'Warm ginger water', 'Boiled cooled water with electrolytes'],
    whenToSeeDoctor: 'Seek prompt medical attention if unable to keep liquids down for 12 hours, blood in stool, or high fever above 102°F.',
    updatedAt: '2026-02-25T14:15:00Z'
  },
  {
    id: 'qa-5',
    category: 'Respiratory',
    disease: 'Bronchial Asthma / Acute Bronchospasm',
    symptoms: ['wheezing', 'shortness of breath', 'tight chest', 'persistent coughing at night', 'rapid breathing'],
    keywords: ['asthma', 'wheeze', 'inhaler', 'breathless', 'chest tight', 'breathing difficulty'],
    answer: 'Asthma is a chronic inflammatory disorder causing airway narrowing, mucus hypersecretion, and airway hyperresponsiveness, triggered by cold air, pollen, dust, or infections.',
    precautions: [
      'Use the prescribed rapid-acting bronchodilator inhaler (e.g., Salbutamol/Albuterol) with spacer.',
      'Sit upright and lean slightly forward; avoid lying flat.',
      'Remove allergen triggers (smoke, dust, pet dander).',
      'Practice slow pursed-lip breathing to control hyperventilation.'
    ],
    urgency: 'high',
    homeRemedies: ['Steam inhalation without harsh chemicals', 'Warm water sips'],
    whenToSeeDoctor: 'Emergency care needed if lips or nails turn blue (cyanosis), inhaler gives no relief after 15 minutes, or struggling to speak full sentences.',
    updatedAt: '2026-03-05T09:10:00Z'
  },
  {
    id: 'qa-6',
    category: 'Neurology',
    disease: 'Migraine Headache',
    symptoms: ['throbbing unilateral headache', 'sensitivity to light and sound', 'nausea', 'visual aura'],
    keywords: ['migraine', 'headache', 'one side head', 'pulsing', 'photophobia', 'aura', 'temple pain'],
    answer: 'Migraine is a neurovascular disorder characterized by recurrent attacks of moderate to severe pulsating headache, often on one side of the head, worsened by routine physical activity.',
    precautions: [
      'Rest in a quiet, dark, well-ventilated room.',
      'Apply a cold ice pack wrapped in a cloth to your forehead or temples.',
      'Stay hydrated; dehydration is a frequent migraine trigger.',
      'Avoid common dietary triggers such as aged cheese, chocolate, caffeine withdrawal, or artificial sweeteners.'
    ],
    urgency: 'moderate',
    homeRemedies: ['Cold compress on forehead', 'Peppermint oil gentle temple massage', 'Ginger tea for nausea'],
    whenToSeeDoctor: 'Consult a physician if headaches occur more than 3 times a month, or seek emergency care if you experience a "thunderclap" sudden explosive headache.',
    updatedAt: '2026-02-18T16:20:00Z'
  },
  {
    id: 'qa-7',
    category: 'Endocrinology',
    disease: 'Hyperglycemia / Diabetic Ketoacidosis Warning',
    symptoms: ['extreme thirst', 'frequent urination', 'fruity breath odor', 'extreme fatigue', 'blurred vision', 'confusion'],
    keywords: ['sugar', 'diabetes', 'high glucose', 'thirst', 'urine frequently', 'fruity breath', 'diabetic'],
    answer: 'High blood sugar (hyperglycemia) can progress to life-threatening Diabetic Ketoacidosis (DKA) when insulin is critically deficient, causing ketone buildup in the blood.',
    precautions: [
      'Check capillary blood glucose immediately with a glucometer.',
      'Administer correction insulin dose strictly according to your physician’s sliding scale protocol.',
      'Drink plenty of plain water to help flush excess ketones and glucose.',
      'Check urine for ketones if blood glucose exceeds 250 mg/dL.'
    ],
    urgency: 'high',
    homeRemedies: ['Continuous sugar-free hydration', 'Complete rest'],
    whenToSeeDoctor: 'Emergency hospital visit if fruity breath odor, persistent nausea/vomiting, or confusion develops.',
    updatedAt: '2026-03-04T11:45:00Z'
  },
  {
    id: 'qa-8',
    category: 'Infectious Diseases',
    disease: 'Typhoid (Enteric Fever)',
    symptoms: ['step-ladder progressive fever', 'abdominal tenderness', 'rose spots', 'constipation or pea-soup diarrhea', 'weakness'],
    keywords: ['typhoid', 'salmonella', 'step ladder fever', 'enteric fever', 'stomach pain with fever'],
    answer: 'Typhoid fever is a life-threatening bacterial infection caused by Salmonella Typhi, usually spread through contaminated food or water in areas with poor sanitation.',
    precautions: [
      'Get a blood culture or Widal test done for confirmation.',
      'Complete the entire regimen of prescribed antibiotics; do not discontinue midway even if fever subsides.',
      'Consume only boiled or UV-purified water and well-cooked hot meals.',
      'Isolate utensils and practice strict personal hygiene.'
    ],
    urgency: 'high',
    homeRemedies: ['Liquid and soft diet like khichdi or vegetable broth', 'Electrolyte hydration'],
    whenToSeeDoctor: 'Consult a physician immediately upon continuous fever rising over 3-4 days.',
    updatedAt: '2026-02-22T13:00:00Z'
  },
  {
    id: 'qa-9',
    category: 'Emergency / Trauma',
    disease: 'Acute Heat Stroke / Hyperthermia',
    symptoms: ['body temperature > 104°F', 'hot dry skin without sweating', 'confusion', 'rapid pulse', 'dizziness', 'fainting'],
    keywords: ['heat stroke', 'loo', 'hot sun', 'high body temperature', 'fainted in heat', 'sun stroke'],
    answer: 'Heat stroke is a medical emergency caused by prolonged exposure to high ambient temperatures, overwhelming the body’s thermoregulatory mechanisms.',
    precautions: [
      'Move the victim into shaded air-conditioned or well-fanned space immediately.',
      'Cool the body rapidly: Apply wet towels or ice packs to neck, armpits, and groin.',
      'Fan the person vigorously while misting with cool water.',
      'Do not give fluids if the person is semi-conscious or vomits.'
    ],
    urgency: 'emergency',
    homeRemedies: ['Cold wet cloth wraps', 'Elevate feet slightly if conscious'],
    whenToSeeDoctor: 'EMERGENCY: Call 108 / 112 immediately. Heat stroke can cause rapid organ damage.',
    updatedAt: '2026-03-07T15:30:00Z'
  },
  {
    id: 'qa-10',
    category: 'Dermatology',
    disease: 'Allergic Contact Dermatitis & Urticaria',
    symptoms: ['intense itching', 'raised red welts', 'swelling of skin', 'burning sensation'],
    keywords: ['skin allergy', 'itching', 'hives', 'rash', 'urticaria', 'red spots', 'itching skin'],
    answer: 'Urticaria (hives) and allergic dermatitis present as itchy erythematous wheals triggered by histamine release in response to allergens, medications, insect stings, or food items.',
    precautions: [
      'Take an over-the-counter or doctor-prescribed non-sedating antihistamine (e.g., Cetirizine 10mg).',
      'Apply calamine lotion to soothe surface pruritus.',
      'Avoid scratching to prevent secondary bacterial infection.',
      'Wear loose-fitting soft cotton garments and avoid hot water baths.'
    ],
    urgency: 'moderate',
    homeRemedies: ['Cold compress or ice cloth', 'Calamine lotion', 'Baking soda or oatmeal bath'],
    whenToSeeDoctor: 'SEEK EMERGENCY CARE if accompanied by lip/tongue swelling, difficulty swallowing, or wheezing (Anaphylaxis).',
    updatedAt: '2026-03-03T17:10:00Z'
  }
];

export const INITIAL_DOCTORS: Doctor[] = [
  {
    id: 'doc-1',
    name: 'Dr. Arvind Mehra, MD',
    specialty: 'General Physician & Internal Medicine',
    qualification: 'MBBS, MD (Medicine) - AIIMS',
    experienceYears: 16,
    clinicName: 'Mehra Family Health Clinic',
    address: 'Plot 42, Sector 14, Main Market Road',
    city: 'Delhi NCR',
    distanceKm: 1.2,
    rating: 4.8,
    reviewsCount: 142,
    phone: '+91 98110 22334',
    consultationFee: 400,
    timings: '09:00 AM - 01:00 PM, 05:00 PM - 09:00 PM',
    availableToday: true,
    coordinates: { lat: 28.6139, lng: 77.2090 }
  },
  {
    id: 'doc-2',
    name: 'Dr. Priya Sundaram, DNB',
    specialty: 'Cardiologist',
    qualification: 'MBBS, MD, DNB (Cardiology), FACC',
    experienceYears: 19,
    clinicName: 'HeartCare Diagnostic & Cardiology Center',
    address: '2nd Floor, Apex MedCenter, MG Road',
    city: 'Delhi NCR',
    distanceKm: 2.8,
    rating: 4.9,
    reviewsCount: 230,
    phone: '+91 98221 33445',
    consultationFee: 800,
    timings: '10:00 AM - 04:00 PM (Mon-Sat)',
    availableToday: true,
    coordinates: { lat: 28.6250, lng: 77.2180 }
  },
  {
    id: 'doc-3',
    name: 'Dr. Rajeshwari Nair',
    specialty: 'Pediatrician & Child Health',
    qualification: 'MBBS, DCH, MD (Pediatrics)',
    experienceYears: 12,
    clinicName: 'Little Angels Child Clinic & Vaccination Center',
    address: 'Near Government High School, Civil Lines',
    city: 'Delhi NCR',
    distanceKm: 1.7,
    rating: 4.7,
    reviewsCount: 98,
    phone: '+91 98450 44556',
    consultationFee: 350,
    timings: '09:30 AM - 01:30 PM, 04:30 PM - 08:00 PM',
    availableToday: true,
    coordinates: { lat: 28.6080, lng: 77.2010 }
  },
  {
    id: 'doc-4',
    name: 'Dr. Farooq Siddiqui, MS',
    specialty: 'Orthopedic Surgeon & Bone Care',
    qualification: 'MBBS, MS (Ortho), Fellowship in Joint Replacement',
    experienceYears: 15,
    clinicName: 'OrthoPlus Bone & Joint Care',
    address: 'Shop 8-10, Green Avenue Complex',
    city: 'Delhi NCR',
    distanceKm: 3.4,
    rating: 4.6,
    reviewsCount: 84,
    phone: '+91 98990 55667',
    consultationFee: 500,
    timings: '11:00 AM - 07:00 PM',
    availableToday: false,
    coordinates: { lat: 28.6320, lng: 77.1950 }
  },
  {
    id: 'doc-5',
    name: 'Dr. Kavita Deshmukh',
    specialty: 'Gynecologist & Obstetrician',
    qualification: 'MBBS, DGO, FICOG',
    experienceYears: 14,
    clinicName: 'Mother & Child Care Wellness Center',
    address: 'Opposite Community Hall, Station Road',
    city: 'Delhi NCR',
    distanceKm: 2.1,
    rating: 4.9,
    reviewsCount: 175,
    phone: '+91 97660 66778',
    consultationFee: 450,
    timings: '10:00 AM - 02:00 PM, 05:00 PM - 08:30 PM',
    availableToday: true,
    coordinates: { lat: 28.6180, lng: 77.2250 }
  },
  {
    id: 'doc-6',
    name: 'Dr. Amitav Sen, MD',
    specialty: 'Pulmonologist & Chest Specialist',
    qualification: 'MBBS, MD (Pulmonary Medicine)',
    experienceYears: 11,
    clinicName: 'BreatheEasy Chest & Allergy Clinic',
    address: '54, Health Hub Arcade, Ring Road',
    city: 'Delhi NCR',
    distanceKm: 4.2,
    rating: 4.7,
    reviewsCount: 110,
    phone: '+91 98330 77889',
    consultationFee: 600,
    timings: '02:00 PM - 08:00 PM',
    availableToday: true,
    coordinates: { lat: 28.5950, lng: 77.2100 }
  },
  {
    id: 'doc-7',
    name: 'Dr. Shalini Gupta',
    specialty: 'Dermatologist & Skin Care',
    qualification: 'MBBS, DVD, MD (Dermatology)',
    experienceYears: 9,
    clinicName: 'DermaGlow Skin & Laser Clinic',
    address: '21/A Central Plaza, Near Metro Pillar 124',
    city: 'Delhi NCR',
    distanceKm: 2.5,
    rating: 4.8,
    reviewsCount: 156,
    phone: '+91 98770 88990',
    consultationFee: 500,
    timings: '11:00 AM - 06:00 PM',
    availableToday: true,
    coordinates: { lat: 28.6220, lng: 77.2310 }
  }
];

export const INITIAL_HOSPITALS: Hospital[] = [
  {
    id: 'hosp-1',
    name: 'District Civil Government Hospital',
    type: 'Government',
    address: 'Hospital Square, Main Civil Lines',
    city: 'Delhi NCR',
    distanceKm: 1.5,
    rating: 4.2,
    phone: '+91 11 2345 6789',
    emergencyPhone: '108 / +91 11 2345 6780',
    ambulanceAvailable: true,
    icuBedsAvailable: 14,
    totalBeds: 250,
    has24x7Emergency: true,
    coordinates: { lat: 28.6190, lng: 77.2150 },
    facilities: ['24x7 Emergency Trauma', 'Jan Aushadhi Pharmacy', 'Blood Bank', 'Free Generic Meds', 'Dialysis Unit', 'Burn Ward']
  },
  {
    id: 'hosp-2',
    name: 'Sanjeevani Multi-Specialty & Trauma Hospital',
    type: 'Private Multi-Specialty',
    address: 'Plot 10, Ring Road By-Pass, Sector 21',
    city: 'Delhi NCR',
    distanceKm: 3.1,
    rating: 4.7,
    phone: '+91 11 4567 8900',
    emergencyPhone: '+91 11 4567 9999 (Toll Free)',
    ambulanceAvailable: true,
    icuBedsAvailable: 8,
    totalBeds: 180,
    has24x7Emergency: true,
    coordinates: { lat: 28.6350, lng: 77.2280 },
    facilities: ['Cardiac Cath Lab', 'Advanced NICU/PICU', 'Rapid Ambulance Fleet (GPS)', 'In-house CT/MRI', 'Emergency Laparoscopy']
  },
  {
    id: 'hosp-3',
    name: 'Rural Primary Health Center (PHC) - Adarsh Gram',
    type: 'Primary Health Center (PHC)',
    address: 'Village Post Office Road, Block IV',
    city: 'Delhi NCR / Outskirts',
    distanceKm: 4.8,
    rating: 4.1,
    phone: '+91 11 2987 6543',
    emergencyPhone: '102 / 108',
    ambulanceAvailable: true,
    icuBedsAvailable: 2,
    totalBeds: 30,
    has24x7Emergency: true,
    coordinates: { lat: 28.5800, lng: 77.1900 },
    facilities: ['Immunization & Maternal Care', 'First Aid Trauma Stabilizer', 'Govt Subsidized Meds', 'Tele-Consultation Link']
  },
  {
    id: 'hosp-4',
    name: 'Apex Super Specialty Cardiac & Trauma Center',
    type: 'Trauma Center',
    address: 'Highway Junction 8, Express Corridor',
    city: 'Delhi NCR',
    distanceKm: 5.6,
    rating: 4.9,
    phone: '+91 11 6789 0123',
    emergencyPhone: '+91 11 6789 9111',
    ambulanceAvailable: true,
    icuBedsAvailable: 19,
    totalBeds: 320,
    has24x7Emergency: true,
    coordinates: { lat: 28.6410, lng: 77.1850 },
    facilities: ['Level 1 Trauma Care', 'Helipad Emergency Access', 'Extracorporeal Life Support (ECMO)', 'Neuro-ICU', '24x7 Blood Bank']
  }
];

export const INITIAL_MODEL_METRICS: ModelMetrics = {
  status: 'trained',
  lastTrainedAt: '2026-03-12T14:30:00Z',
  totalEpochs: 25,
  finalAccuracy: 95.8,
  finalLoss: 0.142,
  vocabularySize: 420,
  classesCount: 10,
  datasetSize: 85,
  architecture: {
    layers: [
      'Input Layer (Tokens Seq Len = 32)',
      'Embedding Layer (Vocab: 420 -> Dim: 64)',
      'Conv1D (64 filters, Kernel size: 3, ReLU)',
      'GlobalMaxPooling1D',
      'Dense Layer (128 units, Dropout 0.4)',
      'Dense Output Layer (10 classes, Softmax)'
    ],
    embeddingDim: 64,
    filters: 64,
    kernelSize: 3,
    dropout: 0.4
  },
  epochHistory: [
    { epoch: 1, loss: 2.30, accuracy: 21.2, valLoss: 2.18, valAccuracy: 28.0 },
    { epoch: 5, loss: 1.54, accuracy: 56.4, valLoss: 1.40, valAccuracy: 61.2 },
    { epoch: 10, loss: 0.88, accuracy: 78.5, valLoss: 0.79, valAccuracy: 82.0 },
    { epoch: 15, loss: 0.42, accuracy: 89.1, valLoss: 0.44, valAccuracy: 88.5 },
    { epoch: 20, loss: 0.22, accuracy: 93.4, valLoss: 0.26, valAccuracy: 92.1 },
    { epoch: 25, loss: 0.14, accuracy: 95.8, valLoss: 0.19, valAccuracy: 94.6 }
  ],
  confusionMatrix: {
    labels: ['Angina', 'Dengue', 'Malaria', 'Gastritis', 'Asthma', 'Migraine', 'DKA', 'Typhoid', 'HeatStroke', 'Urticaria'],
    matrix: [
      [9, 0, 0, 0, 1, 0, 0, 0, 0, 0],
      [0, 8, 1, 0, 0, 0, 0, 1, 0, 0],
      [0, 1, 9, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 10, 0, 0, 0, 0, 0, 0],
      [1, 0, 0, 0, 9, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 10, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 8, 0, 0, 0],
      [0, 1, 0, 0, 0, 0, 0, 9, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 10, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 9]
    ]
  }
};
