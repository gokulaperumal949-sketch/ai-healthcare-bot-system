export type UserRole = 'user' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  age?: number;
  gender?: 'Male' | 'Female' | 'Other';
  bloodGroup?: string;
  allergies?: string;
  medicalHistory?: string;
  emergencyContact?: string;
  createdAt: string;
}

export type UrgencyLevel = 'low' | 'moderate' | 'high' | 'emergency';

export interface QAItem {
  id: string;
  category: string;
  disease: string;
  symptoms: string[];
  keywords: string[];
  answer: string;
  precautions: string[];
  urgency: UrgencyLevel;
  homeRemedies?: string[];
  whenToSeeDoctor: string;
  updatedAt: string;
}

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  qualification: string;
  experienceYears: number;
  clinicName: string;
  address: string;
  city: string;
  distanceKm: number;
  rating: number;
  reviewsCount: number;
  phone: string;
  consultationFee: number;
  timings: string;
  availableToday: boolean;
  coordinates: { lat: number; lng: number };
}

export interface Hospital {
  id: string;
  name: string;
  type: 'Government' | 'Private Multi-Specialty' | 'Community Health Center (CHC)' | 'Primary Health Center (PHC)' | 'Trauma Center';
  address: string;
  city: string;
  distanceKm: number;
  rating: number;
  phone: string;
  emergencyPhone: string;
  ambulanceAvailable: boolean;
  icuBedsAvailable: number;
  totalBeds: number;
  has24x7Emergency: boolean;
  coordinates: { lat: number; lng: number };
  facilities: string[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  predictedDisease?: string;
  confidenceScore?: number;
  urgency?: UrgencyLevel;
  precautions?: string[];
  matchedKeywords?: string[];
  suggestedFacilities?: Array<{
    name: string;
    type: 'doctor' | 'hospital';
    distanceKm: number;
    phone: string;
  }>;
  source?: 'cnn_model' | 'gemini_ai' | 'rule_base';
}

export interface TrainingEpoch {
  epoch: number;
  loss: number;
  accuracy: number;
  valLoss: number;
  valAccuracy: number;
}

export interface ModelMetrics {
  status: 'trained' | 'training' | 'untrained';
  lastTrainedAt: string | null;
  totalEpochs: number;
  finalAccuracy: number;
  finalLoss: number;
  vocabularySize: number;
  classesCount: number;
  datasetSize: number;
  architecture: {
    layers: string[];
    embeddingDim: number;
    filters: number;
    kernelSize: number;
    dropout: number;
  };
  epochHistory: TrainingEpoch[];
  confusionMatrix: {
    labels: string[];
    matrix: number[][];
  };
}
