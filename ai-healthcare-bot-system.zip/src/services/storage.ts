import { Doctor, Hospital, ModelMetrics, QAItem, User } from '../types';
import { INITIAL_DOCTORS, INITIAL_HOSPITALS, INITIAL_MODEL_METRICS, INITIAL_QA_ITEMS, INITIAL_USERS } from '../data/initialData';

const STORAGE_KEYS = {
  USERS: 'healthbot_users_v1',
  CURRENT_USER: 'healthbot_current_user_v1',
  QA_ITEMS: 'healthbot_qa_items_v1',
  DOCTORS: 'healthbot_doctors_v1',
  HOSPITALS: 'healthbot_hospitals_v1',
  MODEL_METRICS: 'healthbot_model_metrics_v1',
  CHAT_HISTORY: 'healthbot_chat_history_v1',
};

export class AppStorage {
  // Users
  static getUsers(): User[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.USERS);
      return data ? JSON.parse(data) : INITIAL_USERS;
    } catch {
      return INITIAL_USERS;
    }
  }

  static saveUsers(users: User[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    } catch (e) {
      console.error('Error saving users', e);
    }
  }

  static getCurrentUser(): User | null {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
      if (data) return JSON.parse(data);
      // Default to demo user
      const defaultUser = INITIAL_USERS[0];
      this.setCurrentUser(defaultUser);
      return defaultUser;
    } catch {
      return INITIAL_USERS[0];
    }
  }

  static setCurrentUser(user: User | null): void {
    try {
      if (user) {
        localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
      } else {
        localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
      }
    } catch (e) {
      console.error('Error setting current user', e);
    }
  }

  // QA Items (Knowledge Base for CNN & Bot)
  static getQAItems(): QAItem[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.QA_ITEMS);
      return data ? JSON.parse(data) : INITIAL_QA_ITEMS;
    } catch {
      return INITIAL_QA_ITEMS;
    }
  }

  static saveQAItems(items: QAItem[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.QA_ITEMS, JSON.stringify(items));
    } catch (e) {
      console.error('Error saving QA items', e);
    }
  }

  // Doctors
  static getDoctors(): Doctor[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.DOCTORS);
      return data ? JSON.parse(data) : INITIAL_DOCTORS;
    } catch {
      return INITIAL_DOCTORS;
    }
  }

  static saveDoctors(doctors: Doctor[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.DOCTORS, JSON.stringify(doctors));
    } catch (e) {
      console.error('Error saving doctors', e);
    }
  }

  // Hospitals
  static getHospitals(): Hospital[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.HOSPITALS);
      return data ? JSON.parse(data) : INITIAL_HOSPITALS;
    } catch {
      return INITIAL_HOSPITALS;
    }
  }

  static saveHospitals(hospitals: Hospital[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.HOSPITALS, JSON.stringify(hospitals));
    } catch (e) {
      console.error('Error saving hospitals', e);
    }
  }

  // CNN Model Metrics
  static getModelMetrics(): ModelMetrics {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.MODEL_METRICS);
      return data ? JSON.parse(data) : INITIAL_MODEL_METRICS;
    } catch {
      return INITIAL_MODEL_METRICS;
    }
  }

  static saveModelMetrics(metrics: ModelMetrics): void {
    try {
      localStorage.setItem(STORAGE_KEYS.MODEL_METRICS, JSON.stringify(metrics));
    } catch (e) {
      console.error('Error saving model metrics', e);
    }
  }

  // Reset to default
  static resetToDefault(): void {
    try {
      localStorage.clear();
      this.saveUsers(INITIAL_USERS);
      this.setCurrentUser(INITIAL_USERS[0]);
      this.saveQAItems(INITIAL_QA_ITEMS);
      this.saveDoctors(INITIAL_DOCTORS);
      this.saveHospitals(INITIAL_HOSPITALS);
      this.saveModelMetrics(INITIAL_MODEL_METRICS);
    } catch (e) {
      console.error('Error resetting storage', e);
    }
  }
}
