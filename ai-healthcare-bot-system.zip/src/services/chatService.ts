import { ChatMessage, User } from '../types';
import { CNNEngine, PredictionResult } from './cnnEngine';
import { AppStorage } from './storage';

export type BotEngineMode = 'hybrid' | 'cnn_only';

export class ChatService {
  /**
   * Process a user message and generate a structured health response
   */
  static async sendMessage(
    message: string,
    history: ChatMessage[],
    userProfile: User | null,
    mode: BotEngineMode = 'hybrid'
  ): Promise<ChatMessage> {
    // Run the local CNN Disease Prediction
    const prediction: PredictionResult = CNNEngine.predict(message);

    // Find nearby doctors or hospitals if urgency is moderate/high/emergency
    const doctors = AppStorage.getDoctors();
    const hospitals = AppStorage.getHospitals();

    let suggestedFacilities: Array<{
      name: string;
      type: 'doctor' | 'hospital';
      distanceKm: number;
      phone: string;
    }> = [];

    if (prediction.urgency === 'emergency') {
      // Prioritize hospitals with trauma/emergency
      suggestedFacilities = hospitals
        .filter(h => h.has24x7Emergency)
        .sort((a, b) => a.distanceKm - b.distanceKm)
        .slice(0, 2)
        .map(h => ({
          name: h.name,
          type: 'hospital',
          distanceKm: h.distanceKm,
          phone: h.emergencyPhone,
        }));
    } else if (prediction.urgency === 'high' || prediction.urgency === 'moderate') {
      // Suggest nearest matching doctor clinic or hospital
      const matchingDocs = doctors
        .filter(d => d.specialty.toLowerCase().includes(prediction.category.toLowerCase()) || d.specialty.includes('General'))
        .slice(0, 2)
        .map(d => ({
          name: `${d.name} (${d.clinicName})`,
          type: 'doctor' as const,
          distanceKm: d.distanceKm,
          phone: d.phone,
        }));

      const nearestHosp = hospitals.slice(0, 1).map(h => ({
        name: h.name,
        type: 'hospital' as const,
        distanceKm: h.distanceKm,
        phone: h.phone,
      }));

      suggestedFacilities = [...matchingDocs, ...nearestHosp].slice(0, 2);
    }

    // Try Gemini API if hybrid mode is selected
    if (mode === 'hybrid') {
      try {
        const response = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message,
            history: history.slice(-6).map(h => ({
              role: h.role === 'assistant' ? 'assistant' : 'user',
              content: h.content,
            })),
            userProfile: userProfile ? {
              name: userProfile.name,
              age: userProfile.age,
              gender: userProfile.gender,
              bloodGroup: userProfile.bloodGroup,
              allergies: userProfile.allergies,
              medicalHistory: userProfile.medicalHistory,
            } : null,
          }),
        });

        if (response.ok) {
          const data = await response.json();
          if (data.reply) {
            return {
              id: 'msg-' + Date.now(),
              role: 'assistant',
              content: data.reply,
              timestamp: new Date().toISOString(),
              predictedDisease: prediction.disease,
              confidenceScore: prediction.confidence,
              urgency: prediction.urgency,
              precautions: prediction.precautions,
              matchedKeywords: prediction.matchedKeywords,
              suggestedFacilities,
              source: 'gemini_ai',
            };
          }
        }
      } catch (err) {
        console.warn('Backend Gemini API unavailable, smoothly utilizing local CNN knowledge base:', err);
      }
    }

    // Local CNN & Clinical Knowledge Base generation
    const content = this.formatLocalCnnResponse(prediction, userProfile);

    return {
      id: 'msg-' + Date.now(),
      role: 'assistant',
      content,
      timestamp: new Date().toISOString(),
      predictedDisease: prediction.disease,
      confidenceScore: prediction.confidence,
      urgency: prediction.urgency,
      precautions: prediction.precautions,
      matchedKeywords: prediction.matchedKeywords,
      suggestedFacilities,
      source: 'cnn_model',
    };
  }

  private static formatLocalCnnResponse(pred: PredictionResult, user: User | null): string {
    let text = '';

    if (pred.isEmergencyAlert) {
      text += `🚨 **CRITICAL MEDICAL EMERGENCY DETECTED**\n\n`;
      text += `Your symptoms indicate potential acute distress (${pred.disease}). Please contact emergency medical services (108 / 112) immediately or go to the nearest emergency trauma room.\n\n`;
    }

    text += `### Clinical Evaluation: **${pred.disease}**\n`;
    text += `*Predicted Category:* ${pred.category} (CNN Risk Match: ${pred.confidence}% confidence)\n\n`;
    text += `${pred.answer}\n\n`;

    if (pred.precautions && pred.precautions.length > 0) {
      text += `#### Recommended Immediate Precautions:\n`;
      pred.precautions.forEach(p => {
        text += `- ${p}\n`;
      });
      text += `\n`;
    }

    if (pred.homeRemedies && pred.homeRemedies.length > 0) {
      text += `#### Safe Supportive Measures:\n`;
      pred.homeRemedies.forEach(r => {
        text += `- ${r}\n`;
      });
      text += `\n`;
    }

    if (user?.allergies && user.allergies !== 'None') {
      text += `⚠️ *Patient Profile Note:* Noted allergy to **${user.allergies}**. Strictly verify all medications with a certified physician.\n\n`;
    }

    text += `#### When to Seek Medical Attention:\n`;
    text += `${pred.whenToSeeDoctor}\n\n`;
    text += `*Note: This AI bot provides initial triage guidance based on trained CNN disease patterns and does not replace in-person examination by a registered physician.*`;

    return text;
  }
}
